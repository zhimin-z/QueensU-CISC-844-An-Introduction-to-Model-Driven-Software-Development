package urml.runtime;
public class TimerPort {
}
