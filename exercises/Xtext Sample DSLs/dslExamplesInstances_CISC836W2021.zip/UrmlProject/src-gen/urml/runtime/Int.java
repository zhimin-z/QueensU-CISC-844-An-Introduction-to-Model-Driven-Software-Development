package urml.runtime;
public class Int extends CommonObj {
	public int val;
	public Int(int v) { val = v; }
}
