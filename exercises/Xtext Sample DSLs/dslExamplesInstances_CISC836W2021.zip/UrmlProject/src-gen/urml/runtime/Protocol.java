package urml.runtime;
import java.util.*;
public class Protocol {
	protected Protocol() {}
	protected List<Signal> incomingSignals;
	protected List<Signal> outgoingSignals;
}
