package urml.runtime;
public class CapsulePortPair {
	public Capsule cap;
	public MessagePort port;
}
