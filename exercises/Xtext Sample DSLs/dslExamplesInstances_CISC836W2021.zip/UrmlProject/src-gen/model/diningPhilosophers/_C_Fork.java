package model.diningPhilosophers;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Fork.
 * @generated
 */
public class _C_Fork extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Fork() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Fork(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_left, _p_right);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_left = new MessagePort("left", new _P_PhilosopherForkProtocol());
	MessagePort _p_right = new MessagePort("right", new _P_PhilosopherForkProtocol());
	private boolean _a_leftWaiting = false;
	private boolean _a_rightWaiting = false;
	/**
	 * A state with name: down
	 */
	private State _state_down = new State(
	
		// name
		"down",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "down");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: up
	 */
	private State _state_up = new State(
	
		// name
		"up",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "up");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pickUpFromLeft
	 */
	private Transition _tran_pickUpFromLeft = new Transition(
	
		// name
		"pickUpFromLeft",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_ack,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_up
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pickUpFromRight
	 */
	private Transition _tran_pickUpFromRight = new Transition(
	
		// name
		"pickUpFromRight",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_ack,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_up
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pickUpFromLeftButIsAlreadyUp
	 */
	private Transition _tran_pickUpFromLeftButIsAlreadyUp = new Transition(
	
		// name
		"pickUpFromLeftButIsAlreadyUp",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_leftWaiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_up
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pickUpFromRightButIsAlreadyUp
	 */
	private Transition _tran_pickUpFromRightButIsAlreadyUp = new Transition(
	
		// name
		"pickUpFromRightButIsAlreadyUp",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_rightWaiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_up
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: switchFromLeftToRight
	 */
	private Transition _tran_switchFromLeftToRight = new Transition(
	
		// name
		"switchFromLeftToRight",
		
		// guard
		() -> {
			return _a_rightWaiting == true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_ack,
				Arrays.asList(
				)));
			_a_rightWaiting = false;System.out.println(this.name + ": logging to logger with: " + "fork exchanged from left to right");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_down
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: switchFromRightToLeft
	 */
	private Transition _tran_switchFromRightToLeft = new Transition(
	
		// name
		"switchFromRightToLeft",
		
		// guard
		() -> {
			return _a_leftWaiting == true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_ack,
				Arrays.asList(
				)));
			_a_leftWaiting = false;System.out.println(this.name + ": logging to logger with: " + "fork exchanged from right to left");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_down
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: putDownForLeft
	 */
	private Transition _tran_putDownForLeft = new Transition(
	
		// name
		"putDownForLeft",
		
		// guard
		() -> {
			return _a_rightWaiting == false;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_down
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: putDownForRight
	 */
	private Transition _tran_putDownForRight = new Transition(
	
		// name
		"putDownForRight",
		
		// guard
		() -> {
			return _a_leftWaiting == false;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_down
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "down":
				return Arrays.asList(_tran_pickUpFromLeft, _tran_pickUpFromRight);
			case "up":
				return Arrays.asList(_tran_pickUpFromLeftButIsAlreadyUp, _tran_pickUpFromRightButIsAlreadyUp, _tran_switchFromLeftToRight, _tran_switchFromRightToLeft, _tran_putDownForLeft, _tran_putDownForRight);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_down;
			_state_down.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "pickUpFromLeft":
				if (_state_down != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_down.exit.run();
					_tran_pickUpFromLeft.action.accept(params);
					_state_up.entry.run();
					currentState = _state_up;
					return false;
				}
			case "pickUpFromRight":
				if (_state_down != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_down.exit.run();
					_tran_pickUpFromRight.action.accept(params);
					_state_up.entry.run();
					currentState = _state_up;
					return false;
				}
			case "pickUpFromLeftButIsAlreadyUp":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_pickUpFromLeftButIsAlreadyUp.action.accept(params);
					currentState = _state_up;
					return false;
				}
			case "pickUpFromRightButIsAlreadyUp":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_pickUpFromRightButIsAlreadyUp.action.accept(params);
					currentState = _state_up;
					return false;
				}
			case "switchFromLeftToRight":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_switchFromLeftToRight.action.accept(params);
					currentState = _state_up;
					return false;
				}
			case "switchFromRightToLeft":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_switchFromRightToLeft.action.accept(params);
					currentState = _state_up;
					return false;
				}
			case "putDownForLeft":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_up.exit.run();
					_tran_putDownForLeft.action.accept(params);
					_state_down.entry.run();
					currentState = _state_down;
					return false;
				}
			case "putDownForRight":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_up.exit.run();
					_tran_putDownForRight.action.accept(params);
					_state_down.entry.run();
					currentState = _state_down;
					return false;
				}
			default:
				return false;
		}
	}
}
