package model.diningPhilosophers;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: RingPhilosopherProtocol
 * @generated
 */
public class _P_RingPhilosopherProtocol extends Protocol {
	public _P_RingPhilosopherProtocol() {
		incomingSignals = Arrays.asList();
		outgoingSignals = Arrays.asList(_s_sign);
	}
	public static Signal _s_sign = new Signal();
}
