package model.diningPhilosophers;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for PhilosophersRing.
 * @generated
 */
public class _C_PhilosophersRing extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_PhilosophersRing() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_PhilosophersRing(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList(_p_phil0signer, _p_phil1signer, _p_phil2signer, _p_phil3signer, _p_phil4signer);
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_phil0, _ci_phil1, _ci_phil2, _ci_phil3, _ci_phil4, _ci_fork0, _ci_fork1, _ci_fork2, _ci_fork3, _ci_fork4);
		_ci_phil0.name = "phil0";
		_ci_phil1.name = "phil1";
		_ci_phil2.name = "phil2";
		_ci_phil3.name = "phil3";
		_ci_phil4.name = "phil4";
		_ci_fork0.name = "fork0";
		_ci_fork1.name = "fork1";
		_ci_fork2.name = "fork2";
		_ci_fork3.name = "fork3";
		_ci_fork4.name = "fork4";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				this, this._p_phil0signer,
				
				// capsule 2, port 2
				_ci_phil0, _ci_phil0._p_signer), 
			new Connector(
				// capsule 1, port 1
				this, this._p_phil1signer,
				
				// capsule 2, port 2
				_ci_phil1, _ci_phil1._p_signer), 
			new Connector(
				// capsule 1, port 1
				this, this._p_phil2signer,
				
				// capsule 2, port 2
				_ci_phil2, _ci_phil2._p_signer), 
			new Connector(
				// capsule 1, port 1
				this, this._p_phil3signer,
				
				// capsule 2, port 2
				_ci_phil3, _ci_phil3._p_signer), 
			new Connector(
				// capsule 1, port 1
				this, this._p_phil4signer,
				
				// capsule 2, port 2
				_ci_phil4, _ci_phil4._p_signer), 
			new Connector(
				// capsule 1, port 1
				_ci_phil0, _ci_phil0._p_left,
				
				// capsule 2, port 2
				_ci_fork4, _ci_fork4._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork4, _ci_fork4._p_left,
				
				// capsule 2, port 2
				_ci_phil4, _ci_phil4._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_phil4, _ci_phil4._p_left,
				
				// capsule 2, port 2
				_ci_fork3, _ci_fork3._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork3, _ci_fork3._p_left,
				
				// capsule 2, port 2
				_ci_phil3, _ci_phil3._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_phil3, _ci_phil3._p_left,
				
				// capsule 2, port 2
				_ci_fork2, _ci_fork2._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork2, _ci_fork2._p_left,
				
				// capsule 2, port 2
				_ci_phil2, _ci_phil2._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_phil2, _ci_phil2._p_left,
				
				// capsule 2, port 2
				_ci_fork1, _ci_fork1._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork1, _ci_fork1._p_left,
				
				// capsule 2, port 2
				_ci_phil1, _ci_phil1._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_phil1, _ci_phil1._p_left,
				
				// capsule 2, port 2
				_ci_fork0, _ci_fork0._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork0, _ci_fork0._p_left,
				
				// capsule 2, port 2
				_ci_phil0, _ci_phil0._p_right)
		);
	}
	MessagePort _p_phil0signer = new MessagePort("phil0signer", new _P_RingPhilosopherProtocol());
	MessagePort _p_phil1signer = new MessagePort("phil1signer", new _P_RingPhilosopherProtocol());
	MessagePort _p_phil2signer = new MessagePort("phil2signer", new _P_RingPhilosopherProtocol());
	MessagePort _p_phil3signer = new MessagePort("phil3signer", new _P_RingPhilosopherProtocol());
	MessagePort _p_phil4signer = new MessagePort("phil4signer", new _P_RingPhilosopherProtocol());
	_C_Philosopher _ci_phil0 = new _C_Philosopher(this);
	_C_Philosopher _ci_phil1 = new _C_Philosopher(this);
	_C_Philosopher _ci_phil2 = new _C_Philosopher(this);
	_C_Philosopher _ci_phil3 = new _C_Philosopher(this);
	_C_Philosopher _ci_phil4 = new _C_Philosopher(this);
	_C_Fork _ci_fork0 = new _C_Fork(this);
	_C_Fork _ci_fork1 = new _C_Fork(this);
	_C_Fork _ci_fork2 = new _C_Fork(this);
	_C_Fork _ci_fork3 = new _C_Fork(this);
	_C_Fork _ci_fork4 = new _C_Fork(this);
	/**
	 * A state with name: one
	 */
	private State _state_one = new State(
	
		// name
		"one",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_phil0signer, new Message(
				_p_phil0signer, 
				_P_RingPhilosopherProtocol._s_sign,
				Arrays.asList(
					new Int(0)
				)));
			passMessage(_p_phil1signer, new Message(
				_p_phil1signer, 
				_P_RingPhilosopherProtocol._s_sign,
				Arrays.asList(
					new Int(1)
				)));
			passMessage(_p_phil2signer, new Message(
				_p_phil2signer, 
				_P_RingPhilosopherProtocol._s_sign,
				Arrays.asList(
					new Int(2)
				)));
			passMessage(_p_phil3signer, new Message(
				_p_phil3signer, 
				_P_RingPhilosopherProtocol._s_sign,
				Arrays.asList(
					new Int(3)
				)));
			passMessage(_p_phil4signer, new Message(
				_p_phil4signer, 
				_P_RingPhilosopherProtocol._s_sign,
				Arrays.asList(
					new Int(4)
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "one":
				return Arrays.asList();
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_one;
			_state_one.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
