package model.diningPhilosophers;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: PhilosopherForkProtocol
 * @generated
 */
public class _P_PhilosopherForkProtocol extends Protocol {
	public _P_PhilosopherForkProtocol() {
		incomingSignals = Arrays.asList(_s_ack);
		outgoingSignals = Arrays.asList(_s_up, _s_down);
	}
	public static Signal _s_ack = new Signal();
	public static Signal _s_up = new Signal();
	public static Signal _s_down = new Signal();
}
