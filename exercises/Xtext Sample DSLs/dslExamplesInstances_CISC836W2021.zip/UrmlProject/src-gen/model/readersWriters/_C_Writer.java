package model.readersWriters;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Writer.
 * @generated
 */
public class _C_Writer extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Writer() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Writer(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_con, _p_write);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_con = new MessagePort("con", new _P_ControllerRW());
	MessagePort _p_write = new MessagePort("write", new _P_ReadAndWriteThings());
	final TimerPort _tp_timer = new TimerPort();
	private boolean _a_writeRequestSent = false;
	private int _a_timeoutPeriod = 200;
	/**
	 * A state with name: notWriting
	 */
	private State _state_notWriting = new State(
	
		// name
		"notWriting",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: writing
	 */
	private State _state_writing = new State(
	
		// name
		"writing",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "writing 1234");
			passMessage(_p_write, new Message(
				_p_write, 
				_P_ReadAndWriteThings._s_write,
				Arrays.asList(
					new Int(1234)
				)));
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: getWriting
	 */
	private Transition _tran_getWriting = new Transition(
	
		// name
		"getWriting",
		
		// guard
		() -> {
			return _a_writeRequestSent == false;
		},
		
		// action code
		params -> {
			passMessage(_p_con, new Message(
				_p_con, 
				_P_ControllerRW._s_acquireWrite,
				Arrays.asList(
				)));
			_a_writeRequestSent = true;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: goWriting
	 */
	private Transition _tran_goWriting = new Transition(
	
		// name
		"goWriting",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_writeRequestSent = false;System.out.println(this.name + ": logging to logger with: " + "goWriting");
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_timeoutPeriod);
			instants.put(_tp_timer, timeoutInstant);}
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_con, _P_ControllerRW._s_acknowledge
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: backToNotWriting
	 */
	private Transition _tran_backToNotWriting = new Transition(
	
		// name
		"backToNotWriting",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_con, new Message(
				_p_con, 
				_P_ControllerRW._s_releaseWrite,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_timer
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "notWriting":
				return Arrays.asList(_tran_getWriting, _tran_goWriting);
			case "writing":
				return Arrays.asList(_tran_backToNotWriting);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_notWriting;
			_state_notWriting.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "getWriting":
				if (_state_notWriting != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_getWriting.action.accept(params);
					currentState = _state_notWriting;
					return false;
				}
			case "goWriting":
				if (_state_notWriting != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_notWriting.exit.run();
					_tran_goWriting.action.accept(params);
					_state_writing.entry.run();
					currentState = _state_writing;
					return false;
				}
			case "backToNotWriting":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_writing.exit.run();
					_tran_backToNotWriting.action.accept(params);
					_state_notWriting.entry.run();
					currentState = _state_notWriting;
					return false;
				}
			default:
				return false;
		}
	}
}
