package model.parcelRouter;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Generator.
 * @generated
 */
public class _C_Generator extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Generator() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Generator(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_gettingOut);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_gettingOut = new MessagePort("gettingOut", new _P_ParcelPassage());
	final TimerPort _tp_timer = new TimerPort();
	private int _a_timeoutPeriod = 10000;
	private int _a_destinationId = 1;
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_timeoutPeriod);
			instants.put(_tp_timer, timeoutInstant);}
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: sending
	 */
	private Transition _tran_sending = new Transition(
	
		// name
		"sending",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_timeoutPeriod);
			instants.put(_tp_timer, timeoutInstant);}
			passMessage(_p_gettingOut, new Message(
				_p_gettingOut, 
				_P_ParcelPassage._s_sendParcel,
				Arrays.asList(
					new Int(_a_destinationId)
				)));
			System.out.println(this.name + ": logging to logger with: " + "generator sending out a parcel to bin " + _a_destinationId);
			_a_destinationId = _a_destinationId + 1;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_timer
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList(_tran_sending);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_single;
			_state_single.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "sending":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_sending.action.accept(params);
					currentState = _state_single;
					return false;
				}
			default:
				return false;
		}
	}
}
