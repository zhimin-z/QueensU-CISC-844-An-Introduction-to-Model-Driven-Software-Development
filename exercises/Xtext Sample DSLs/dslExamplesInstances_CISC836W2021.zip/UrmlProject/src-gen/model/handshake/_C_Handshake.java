package model.handshake;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Handshake.
 * @generated
 */
public class _C_Handshake extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Handshake() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Handshake(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_sender, _ci_receiver);
		_ci_sender.name = "sender";
		_ci_receiver.name = "receiver";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_sender, _ci_sender._p_hand,
				
				// capsule 2, port 2
				_ci_receiver, _ci_receiver._p_hand)
		);
	}
	_C_Originator _ci_sender = new _C_Originator(this);
	_C_Receiver _ci_receiver = new _C_Receiver(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
