package model.handshake;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: HandshakeProtocol
 * @generated
 */
public class _P_HandshakeProtocol extends Protocol {
	public _P_HandshakeProtocol() {
		incomingSignals = Arrays.asList();
		outgoingSignals = Arrays.asList(_s_shake);
	}
	public static Signal _s_shake = new Signal();
}
