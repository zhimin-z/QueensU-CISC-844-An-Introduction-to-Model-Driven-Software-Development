package model.diningPhilosopher2;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Capsule.
 * @generated
 */
public class _C_Capsule extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Capsule() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Capsule(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_phil0, _ci_phil1, _ci_phil2, _ci_fork0, _ci_fork1, _ci_fork2);
		_ci_phil0.name = "phil0";
		_ci_phil1.name = "phil1";
		_ci_phil2.name = "phil2";
		_ci_fork0.name = "fork0";
		_ci_fork1.name = "fork1";
		_ci_fork2.name = "fork2";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_phil0, _ci_phil0._p_left,
				
				// capsule 2, port 2
				_ci_fork0, _ci_fork0._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork0, _ci_fork0._p_left,
				
				// capsule 2, port 2
				_ci_phil1, _ci_phil1._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_phil1, _ci_phil1._p_left,
				
				// capsule 2, port 2
				_ci_fork1, _ci_fork1._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork1, _ci_fork1._p_left,
				
				// capsule 2, port 2
				_ci_phil2, _ci_phil2._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_phil2, _ci_phil2._p_left,
				
				// capsule 2, port 2
				_ci_fork2, _ci_fork2._p_right), 
			new Connector(
				// capsule 1, port 1
				_ci_fork2, _ci_fork2._p_left,
				
				// capsule 2, port 2
				_ci_phil0, _ci_phil0._p_right)
		);
	}
	_C_Philosopher _ci_phil0 = new _C_Philosopher(this);
	_C_Philosopher _ci_phil1 = new _C_Philosopher(this);
	_C_Philosopher _ci_phil2 = new _C_Philosopher(this);
	_C_Fork _ci_fork0 = new _C_Fork(this);
	_C_Fork _ci_fork1 = new _C_Fork(this);
	_C_Fork _ci_fork2 = new _C_Fork(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
