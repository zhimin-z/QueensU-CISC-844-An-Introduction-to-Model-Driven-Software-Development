package model.diningPhilosopher2;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Fork.
 * @generated
 */
public class _C_Fork extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Fork() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Fork(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_left, _p_right);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_left = new MessagePort("left", new _P_PhilosopherForkProtocol());
	MessagePort _p_right = new MessagePort("right", new _P_PhilosopherForkProtocol());
	/**
	 * A state with name: up
	 */
	private State _state_up = new State(
	
		// name
		"up",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "up");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: down
	 */
	private State _state_down = new State(
	
		// name
		"down",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "down");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: sendAvailL
	 */
	private Transition _tran_sendAvailL = new Transition(
	
		// name
		"sendAvailL",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_avail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "sendAvailL");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_checkAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: sendAvailR
	 */
	private Transition _tran_sendAvailR = new Transition(
	
		// name
		"sendAvailR",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_avail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "sendAvailR");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_checkAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: sendNotAvailL
	 */
	private Transition _tran_sendNotAvailL = new Transition(
	
		// name
		"sendNotAvailL",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_notAvail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "sendNotAvailL");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_checkAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: sendNotAvailR
	 */
	private Transition _tran_sendNotAvailR = new Transition(
	
		// name
		"sendNotAvailR",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_notAvail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "sendNotAvailR");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_checkAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: picked
	 */
	private Transition _tran_picked = new Transition(
	
		// name
		"picked",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_pick
			),
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_pick
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: dropped
	 */
	private Transition _tran_dropped = new Transition(
	
		// name
		"dropped",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_drop
			),
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_drop
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "up":
				return Arrays.asList(_tran_sendNotAvailL, _tran_sendNotAvailR, _tran_dropped);
			case "down":
				return Arrays.asList(_tran_sendAvailL, _tran_sendAvailR, _tran_picked);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_down;
			_state_down.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "sendAvailL":
				if (_state_down != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_sendAvailL.action.accept(params);
					currentState = _state_down;
					return false;
				}
			case "sendAvailR":
				if (_state_down != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_sendAvailR.action.accept(params);
					currentState = _state_down;
					return false;
				}
			case "sendNotAvailL":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_sendNotAvailL.action.accept(params);
					currentState = _state_up;
					return false;
				}
			case "sendNotAvailR":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_sendNotAvailR.action.accept(params);
					currentState = _state_up;
					return false;
				}
			case "picked":
				if (_state_down != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_down.exit.run();
					_tran_picked.action.accept(params);
					_state_up.entry.run();
					currentState = _state_up;
					return false;
				}
			case "dropped":
				if (_state_up != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_up.exit.run();
					_tran_dropped.action.accept(params);
					_state_down.entry.run();
					currentState = _state_down;
					return false;
				}
			default:
				return false;
		}
	}
}
