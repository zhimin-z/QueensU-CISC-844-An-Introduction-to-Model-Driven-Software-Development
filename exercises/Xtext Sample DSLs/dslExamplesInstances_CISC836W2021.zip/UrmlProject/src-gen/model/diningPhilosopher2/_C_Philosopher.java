package model.diningPhilosopher2;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Philosopher.
 * @generated
 */
public class _C_Philosopher extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Philosopher() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Philosopher(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_left, _p_right);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_left = new MessagePort("left", new _P_PhilosopherForkProtocol());
	MessagePort _p_right = new MessagePort("right", new _P_PhilosopherForkProtocol());
	/**
	 * A state with name: think
	 */
	private State _state_think = new State(
	
		// name
		"think",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "think");
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: pickedL
	 */
	private State _state_pickedL = new State(
	
		// name
		"pickedL",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "pickedL");
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: pickedR
	 */
	private State _state_pickedR = new State(
	
		// name
		"pickedR",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "pickedR");
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: eat
	 */
	private State _state_eat = new State(
	
		// name
		"eat",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "eat");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: droppedLeft
	 */
	private State _state_droppedLeft = new State(
	
		// name
		"droppedLeft",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "droppedLeft");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: droppedRight
	 */
	private State _state_droppedRight = new State(
	
		// name
		"droppedRight",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "droppedRight");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: reask1L
	 */
	private Transition _tran_reask1L = new Transition(
	
		// name
		"reask1L",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "reask1L");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_notAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pick1L
	 */
	private Transition _tran_pick1L = new Transition(
	
		// name
		"pick1L",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_pick,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "pick1L");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_avail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: reask2R
	 */
	private Transition _tran_reask2R = new Transition(
	
		// name
		"reask2R",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "reask2R");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_notAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pick2R
	 */
	private Transition _tran_pick2R = new Transition(
	
		// name
		"pick2R",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_pick,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "pick2R");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_avail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: reask1R
	 */
	private Transition _tran_reask1R = new Transition(
	
		// name
		"reask1R",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "reask1r");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_notAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pick1R
	 */
	private Transition _tran_pick1R = new Transition(
	
		// name
		"pick1R",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_pick,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "pick1R");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_avail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: reask2L
	 */
	private Transition _tran_reask2L = new Transition(
	
		// name
		"reask2L",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_checkAvail,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "reask2L");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_notAvail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pick2L
	 */
	private Transition _tran_pick2L = new Transition(
	
		// name
		"pick2L",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_pick,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "pick2L");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_avail
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: drop1L
	 */
	private Transition _tran_drop1L = new Transition(
	
		// name
		"drop1L",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_drop,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "drop1L");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: drop1R
	 */
	private Transition _tran_drop1R = new Transition(
	
		// name
		"drop1R",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_drop,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "drop1R");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: drop2L
	 */
	private Transition _tran_drop2L = new Transition(
	
		// name
		"drop2L",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_drop,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "drop2L");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: drop2R
	 */
	private Transition _tran_drop2R = new Transition(
	
		// name
		"drop2R",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_drop,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "drop2R");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "think":
				return Arrays.asList(_tran_reask1L, _tran_pick1L, _tran_reask1R, _tran_pick1R);
			case "pickedL":
				return Arrays.asList(_tran_reask2R, _tran_pick2R);
			case "pickedR":
				return Arrays.asList(_tran_reask2L, _tran_pick2L);
			case "eat":
				return Arrays.asList(_tran_drop1L, _tran_drop1R);
			case "droppedLeft":
				return Arrays.asList(_tran_drop2R);
			case "droppedRight":
				return Arrays.asList(_tran_drop2L);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_think;
			_state_think.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "reask1L":
				if (_state_think != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_reask1L.action.accept(params);
					currentState = _state_think;
					return false;
				}
			case "pick1L":
				if (_state_think != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_think.exit.run();
					_tran_pick1L.action.accept(params);
					_state_pickedL.entry.run();
					currentState = _state_pickedL;
					return false;
				}
			case "reask2R":
				if (_state_pickedL != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_reask2R.action.accept(params);
					currentState = _state_pickedL;
					return false;
				}
			case "pick2R":
				if (_state_pickedL != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_pickedL.exit.run();
					_tran_pick2R.action.accept(params);
					_state_eat.entry.run();
					currentState = _state_eat;
					return false;
				}
			case "reask1R":
				if (_state_think != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_reask1R.action.accept(params);
					currentState = _state_think;
					return false;
				}
			case "pick1R":
				if (_state_think != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_think.exit.run();
					_tran_pick1R.action.accept(params);
					_state_pickedR.entry.run();
					currentState = _state_pickedR;
					return false;
				}
			case "reask2L":
				if (_state_pickedR != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_reask2L.action.accept(params);
					currentState = _state_pickedR;
					return false;
				}
			case "pick2L":
				if (_state_pickedR != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_pickedR.exit.run();
					_tran_pick2L.action.accept(params);
					_state_eat.entry.run();
					currentState = _state_eat;
					return false;
				}
			case "drop1L":
				if (_state_eat != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_eat.exit.run();
					_tran_drop1L.action.accept(params);
					_state_droppedLeft.entry.run();
					currentState = _state_droppedLeft;
					return false;
				}
			case "drop1R":
				if (_state_eat != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_eat.exit.run();
					_tran_drop1R.action.accept(params);
					_state_droppedRight.entry.run();
					currentState = _state_droppedRight;
					return false;
				}
			case "drop2L":
				if (_state_droppedRight != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_droppedRight.exit.run();
					_tran_drop2L.action.accept(params);
					_state_think.entry.run();
					currentState = _state_think;
					return false;
				}
			case "drop2R":
				if (_state_droppedLeft != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_droppedLeft.exit.run();
					_tran_drop2R.action.accept(params);
					_state_think.entry.run();
					currentState = _state_think;
					return false;
				}
			default:
				return false;
		}
	}
}
