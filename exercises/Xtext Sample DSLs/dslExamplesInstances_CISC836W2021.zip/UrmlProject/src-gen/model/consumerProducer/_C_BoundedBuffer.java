package model.consumerProducer;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for BoundedBuffer.
 * @generated
 */
public class _C_BoundedBuffer extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_BoundedBuffer() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_BoundedBuffer(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_consumer, _p_producer);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_consumer = new MessagePort("consumer", new _P_BufferProtocol());
	MessagePort _p_producer = new MessagePort("producer", new _P_BufferProtocol());
	private int _a_a = 0;
	private int _a_b = 0;
	private int _a_c = 0;
	private int _a_d = 0;
	private int _a_e = 0;
	/**
	 * A state with name: zero
	 */
	private State _state_zero = new State(
	
		// name
		"zero",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: one
	 */
	private State _state_one = new State(
	
		// name
		"one",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: two
	 */
	private State _state_two = new State(
	
		// name
		"two",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: three
	 */
	private State _state_three = new State(
	
		// name
		"three",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: four
	 */
	private State _state_four = new State(
	
		// name
		"four",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: five
	 */
	private State _state_five = new State(
	
		// name
		"five",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_3
	 */
	private Transition _tran__noname_3 = new Transition(
	
		// name
		"_noname_3",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_a_ = ((Int) (params.get(0))).val;
			_a_a = _i_a_;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_producer, _P_BufferProtocol._s_put
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_4
	 */
	private Transition _tran__noname_4 = new Transition(
	
		// name
		"_noname_4",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_b_ = ((Int) (params.get(0))).val;
			_a_b = _i_b_;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_producer, _P_BufferProtocol._s_put
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_5
	 */
	private Transition _tran__noname_5 = new Transition(
	
		// name
		"_noname_5",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_c_ = ((Int) (params.get(0))).val;
			_a_c = _i_c_;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_producer, _P_BufferProtocol._s_put
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_6
	 */
	private Transition _tran__noname_6 = new Transition(
	
		// name
		"_noname_6",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_d_ = ((Int) (params.get(0))).val;
			_a_d = _i_d_;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_producer, _P_BufferProtocol._s_put
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_7
	 */
	private Transition _tran__noname_7 = new Transition(
	
		// name
		"_noname_7",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_e_ = ((Int) (params.get(0))).val;
			_a_e = _i_e_;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_producer, _P_BufferProtocol._s_put
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_8
	 */
	private Transition _tran__noname_8 = new Transition(
	
		// name
		"_noname_8",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_consumer, new Message(
				_p_consumer, 
				_P_BufferProtocol._s_get,
				Arrays.asList(
					new Int(_a_e)
				)));
			_a_e = 0;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_9
	 */
	private Transition _tran__noname_9 = new Transition(
	
		// name
		"_noname_9",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_consumer, new Message(
				_p_consumer, 
				_P_BufferProtocol._s_get,
				Arrays.asList(
					new Int(_a_d)
				)));
			_a_d = 0;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_10
	 */
	private Transition _tran__noname_10 = new Transition(
	
		// name
		"_noname_10",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_consumer, new Message(
				_p_consumer, 
				_P_BufferProtocol._s_get,
				Arrays.asList(
					new Int(_a_c)
				)));
			_a_c = 0;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_11
	 */
	private Transition _tran__noname_11 = new Transition(
	
		// name
		"_noname_11",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_consumer, new Message(
				_p_consumer, 
				_P_BufferProtocol._s_get,
				Arrays.asList(
					new Int(_a_b)
				)));
			_a_b = 0;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_12
	 */
	private Transition _tran__noname_12 = new Transition(
	
		// name
		"_noname_12",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_consumer, new Message(
				_p_consumer, 
				_P_BufferProtocol._s_get,
				Arrays.asList(
					new Int(_a_a)
				)));
			_a_a = 0;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "zero":
				return Arrays.asList(_tran__noname_3);
			case "one":
				return Arrays.asList(_tran__noname_4, _tran__noname_12);
			case "two":
				return Arrays.asList(_tran__noname_5, _tran__noname_11);
			case "three":
				return Arrays.asList(_tran__noname_6, _tran__noname_10);
			case "four":
				return Arrays.asList(_tran__noname_7, _tran__noname_9);
			case "five":
				return Arrays.asList(_tran__noname_8);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_zero;
			_state_zero.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "_noname_3":
				if (_state_zero != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_zero.exit.run();
					_tran__noname_3.action.accept(params);
					_state_one.entry.run();
					currentState = _state_one;
					return false;
				}
			case "_noname_4":
				if (_state_one != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_one.exit.run();
					_tran__noname_4.action.accept(params);
					_state_two.entry.run();
					currentState = _state_two;
					return false;
				}
			case "_noname_5":
				if (_state_two != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_two.exit.run();
					_tran__noname_5.action.accept(params);
					_state_three.entry.run();
					currentState = _state_three;
					return false;
				}
			case "_noname_6":
				if (_state_three != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_three.exit.run();
					_tran__noname_6.action.accept(params);
					_state_four.entry.run();
					currentState = _state_four;
					return false;
				}
			case "_noname_7":
				if (_state_four != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_four.exit.run();
					_tran__noname_7.action.accept(params);
					_state_five.entry.run();
					currentState = _state_five;
					return false;
				}
			case "_noname_8":
				if (_state_five != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_five.exit.run();
					_tran__noname_8.action.accept(params);
					_state_four.entry.run();
					currentState = _state_four;
					return false;
				}
			case "_noname_9":
				if (_state_four != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_four.exit.run();
					_tran__noname_9.action.accept(params);
					_state_three.entry.run();
					currentState = _state_three;
					return false;
				}
			case "_noname_10":
				if (_state_three != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_three.exit.run();
					_tran__noname_10.action.accept(params);
					_state_two.entry.run();
					currentState = _state_two;
					return false;
				}
			case "_noname_11":
				if (_state_two != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_two.exit.run();
					_tran__noname_11.action.accept(params);
					_state_one.entry.run();
					currentState = _state_one;
					return false;
				}
			case "_noname_12":
				if (_state_one != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_one.exit.run();
					_tran__noname_12.action.accept(params);
					_state_zero.entry.run();
					currentState = _state_zero;
					return false;
				}
			default:
				return false;
		}
	}
}
