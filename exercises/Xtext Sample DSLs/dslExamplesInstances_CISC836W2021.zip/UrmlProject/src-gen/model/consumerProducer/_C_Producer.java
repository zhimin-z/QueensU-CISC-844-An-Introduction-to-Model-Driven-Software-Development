package model.consumerProducer;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Producer.
 * @generated
 */
public class _C_Producer extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Producer() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Producer(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_toPut);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_toPut = new MessagePort("toPut", new _P_BufferProtocol());
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
			int _l_x = 1;
			while (_l_x < 8) {
				passMessage(_p_toPut, new Message(
					_p_toPut, 
					_P_BufferProtocol._s_put,
					Arrays.asList(
						new Int(_l_x)
					)));
				_l_x = _l_x + 1;
			}
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: _noname_2
	 */
	private Transition _tran__noname_2 = new Transition(
	
		// name
		"_noname_2",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList();
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran__noname_2.action.accept(new ArrayList<>());
			currentState = _state_single;
			_state_single.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
