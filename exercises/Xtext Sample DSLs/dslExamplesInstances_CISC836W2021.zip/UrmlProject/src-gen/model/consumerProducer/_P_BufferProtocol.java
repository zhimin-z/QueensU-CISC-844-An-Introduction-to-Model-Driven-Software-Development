package model.consumerProducer;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: BufferProtocol
 * @generated
 */
public class _P_BufferProtocol extends Protocol {
	public _P_BufferProtocol() {
		incomingSignals = Arrays.asList(_s_get);
		outgoingSignals = Arrays.asList(_s_put);
	}
	public static Signal _s_get = new Signal();
	public static Signal _s_put = new Signal();
}
