package model.consumerProducer;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for ConsumerProducer.
 * @generated
 */
public class _C_ConsumerProducer extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_ConsumerProducer() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_ConsumerProducer(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_c, _ci_p, _ci_b);
		_ci_c.name = "c";
		_ci_p.name = "p";
		_ci_b.name = "b";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_c, _ci_c._p_toGet,
				
				// capsule 2, port 2
				_ci_b, _ci_b._p_consumer), 
			new Connector(
				// capsule 1, port 1
				_ci_p, _ci_p._p_toPut,
				
				// capsule 2, port 2
				_ci_b, _ci_b._p_producer)
		);
	}
	_C_Consumer _ci_c = new _C_Consumer(this);
	_C_Producer _ci_p = new _C_Producer(this);
	_C_BoundedBuffer _ci_b = new _C_BoundedBuffer(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
