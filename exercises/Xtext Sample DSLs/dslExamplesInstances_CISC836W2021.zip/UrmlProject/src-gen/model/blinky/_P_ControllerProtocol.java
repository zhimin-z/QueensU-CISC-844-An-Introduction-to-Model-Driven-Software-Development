package model.blinky;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: ControllerProtocol
 * @generated
 */
public class _P_ControllerProtocol extends Protocol {
	public _P_ControllerProtocol() {
		incomingSignals = Arrays.asList(_s_start, _s_stop);
		outgoingSignals = Arrays.asList();
	}
	public static Signal _s_start = new Signal();
	public static Signal _s_stop = new Signal();
}
