package model.blinky;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for BlinkingLight.
 * @generated
 */
public class _C_BlinkingLight extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_BlinkingLight() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_BlinkingLight(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_connectToController);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_connectToController = new MessagePort("connectToController", new _P_ControllerProtocol());
	final TimerPort _tp_onAndOff_Timer = new TimerPort();
	private int _a_onAndOff_Period = 1000;
	/**
	 * A state with name: off
	 */
	private State _state_off = new State(
	
		// name
		"off",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: blinking
	 */
	private State _state_blinking = new State(
	
		// name
		"blinking",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: subOn
	 */
	private State _state_subOn = new State(
	
		// name
		"subOn",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_onAndOff_Period);
			instants.put(_tp_onAndOff_Timer, timeoutInstant);}
			System.out.println(this.name + ": logging to logger with: " + "Lights " + "turn to yellow for " + _a_onAndOff_Period / 1000 + " seconds...");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: subOff
	 */
	private State _state_subOff = new State(
	
		// name
		"subOff",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_onAndOff_Period);
			instants.put(_tp_onAndOff_Timer, timeoutInstant);}
			System.out.println(this.name + ": logging to logger with: " + "Lights turn off for " + _a_onAndOff_Period / 1000 + " seconds");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: on2off
	 */
	private Transition _tran_on2off = new Transition(
	
		// name
		"on2off",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_onAndOff_Timer
	);
	/**
	 * A transition with name: subOff2on
	 */
	private Transition _tran_subOff2on = new Transition(
	
		// name
		"subOff2on",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_onAndOff_Timer
	);
	/**
	 * A transition with name: subInit
	 */
	private Transition _tran_subInit = new Transition(
	
		// name
		"subInit",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: startBlinking
	 */
	private Transition _tran_startBlinking = new Transition(
	
		// name
		"startBlinking",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_connectToController, _P_ControllerProtocol._s_start
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: stopBlinking
	 */
	private Transition _tran_stopBlinking = new Transition(
	
		// name
		"stopBlinking",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_connectToController, _P_ControllerProtocol._s_stop
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "off":
				return Arrays.asList(_tran_startBlinking);
			case "blinking":
				return Arrays.asList(_tran_stopBlinking);
			case "subOn":
				return Arrays.asList(_tran_on2off, _tran_stopBlinking);
			case "subOff":
				return Arrays.asList(_tran_subOff2on, _tran_stopBlinking);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
			_tran_init.action.accept(new ArrayList<>());
			currentState = _state_off;
			_state_off.entry.run();
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "on2off":
				if (_state_subOn != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_subOn.exit.run();
					_tran_on2off.action.accept(params);
					_state_subOff.entry.run();
					currentState = _state_subOff;
					return false;
				}
			case "subOff2on":
				if (_state_subOff != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_subOff.exit.run();
					_tran_subOff2on.action.accept(params);
					_state_subOn.entry.run();
					currentState = _state_subOn;
					return false;
				}
			case "startBlinking":
				if (_state_off != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_off.exit.run();
					_tran_startBlinking.action.accept(params);
					_state_blinking.entry.run();
					_state_subOn.entry.run();
					currentState = _state_subOn;
					return false;
				}
			case "stopBlinking":
				if (_state_blinking != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_blinking.exit.run();
					_tran_stopBlinking.action.accept(params);
					_state_off.entry.run();
					currentState = _state_off;
					return false;
				}
			default:
				return false;
		}
	}
}
