package model.blinky;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Top.
 * @generated
 */
public class _C_Top extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Top() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Top(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_blinky, _ci_controller);
		_ci_blinky.name = "blinky";
		_ci_controller.name = "controller";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_blinky, _ci_blinky._p_connectToController,
				
				// capsule 2, port 2
				_ci_controller, _ci_controller._p_connectToLight)
		);
	}
	_C_BlinkingLight _ci_blinky = new _C_BlinkingLight(this);
	_C_Controller _ci_controller = new _C_Controller(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
