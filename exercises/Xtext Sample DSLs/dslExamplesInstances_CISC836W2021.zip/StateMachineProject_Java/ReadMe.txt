Folder 'src-gen' is a symbolic link to folder 'src-gen' in project 'StatemachineProject'.
The purpose of this project is to allow the execution of the Java code generated from the 
state machine in 'StatemachineProject/src'