start 
. directly from Eclipse: right-click package, run as 'Java Application', default port used: 8080
. cygwin command line: 'java animation.ParcelRouter' in directory '<workspace>/ParcelRouterAnimation/bin'