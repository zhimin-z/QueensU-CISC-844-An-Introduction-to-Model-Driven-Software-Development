package animation.model;

public class Model {
	
	public Stage stages[] = {
			new Stage(), // top
			new Stage(), // left
			new Stage() // right
		};
	public int[] bins = {0, 0, 0, 0};
}
