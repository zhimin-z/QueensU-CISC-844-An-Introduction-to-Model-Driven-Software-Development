package animation.model;

public class Stage {
	
	public int chutes[] = {0,0};
	public int switcher = 0;
	public int door = -1;
}
