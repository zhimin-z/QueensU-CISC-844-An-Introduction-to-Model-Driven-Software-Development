package linkedlistpluginproject;

import linkedlist.LinkedlistFactory;
import linkedlist.List;
import linkedlist.Node;
import linkedlist.impl.LinkedlistFactoryImpl;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.ecore.util.Diagnostician;

public class LinkedList1 {
 
	public static void main(String[] args) {
	    System.out.println("Hi there!");
	    System.out.println("Let's build some linked lists, shall we?");
	    System.out.println("Creating list1");
	    
		Node[] nodes;
		LinkedlistFactoryImpl.init();
	    // Retrieve the default factory singleton
	    LinkedlistFactory factory = LinkedlistFactory.eINSTANCE;
	    // create a bunch of nodes
	    nodes = new Node[10];
	    for (int i=0; i<10; i++) {
	    	nodes[i] = factory.createNode();
	    	nodes[i].setName("n"+i);
	    	if (i>0) 
	    		nodes[i].setPrev(nodes[i-1]);
	    }
	    List list1 = factory.createList();
	    list1.setHead(nodes[0]);
	    list1.setName("my_super_list");
	    
	    Diagnostic validate = Diagnostician.INSTANCE.validate(list1);
	    System.out.print("Validating list1: ");
	    if (validate.getSeverity()==Diagnostic.OK) 
	    	System.out.println("ok");
	    else
	    	System.out.println("something wrong");
	    System.out.print("Here is list 1: ");	    
	    System.out.println(list1.toString());
	    System.out.print("Does it contain a node with name 'n3'? ");
	    if (list1.find("n3")) System.out.println("Sure does!"); 
	    else System.out.println("Nope"); 
	    System.out.print("Does it contain a node with name 'n10'? ");
	    if (list1.find("n10")) System.out.println("Yes!");
	    else System.out.println("Nope"); 

	    System.out.println("Let's create list2");
	    List list2 = factory.createList();
	    list1.setName("an_empty_list");
	    
	    validate = Diagnostician.INSTANCE.validate(list2);
	    System.out.print("Validating list2: ");
	    if (validate.getSeverity()==Diagnostic.OK) 
	    	System.out.println("ok");
	    else
	    	System.out.println("something wrong");
	}
}