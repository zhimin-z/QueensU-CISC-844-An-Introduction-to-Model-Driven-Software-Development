/**
 */
package linkedlist.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import linkedlist.LinkedlistFactory;
import linkedlist.Node;
import linkedlist.impl.LinkedlistFactoryImpl;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link linkedlist.Node#find(java.lang.String) <em>Find</em>}</li>
 *   <li>{@link linkedlist.Node#toString() <em>To String</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class NodeTest extends TestCase {

	/**
	 * The fixture for this Node test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Node fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(NodeTest.class);
	}

	/**
	 * Constructs a new Node test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NodeTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Node test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Node fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Node test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Node getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(LinkedlistFactory.eINSTANCE.createNode());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	
	/**
	 * Tests the '{@link linkedlist.Node#find(java.lang.String) <em>Find</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see linkedlist.Node#find(java.lang.String)
	 * @generated
	 */
	public void testFind__String() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link linkedlist.Node#toString() <em>To String</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see linkedlist.Node#toString()
	 * @generated
	 */
	public void testToString() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}


	public Node n1, n2, n3;
	
	// initialize some nodes
	public void initNodes() {
		// initialize factory
		LinkedlistFactoryImpl.init();
	    // retrieve the default factory singleton
	    LinkedlistFactory factory = LinkedlistFactory.eINSTANCE;
	    // create an instance of Node
		n1 = factory.createNode();
		n2 = factory.createNode();
		n3 = factory.createNode();
		// set their attributes
		n1.setName("n1");
		n1.setNext(n2);
		n2.setName("n2");
		n2.setNext(n3);
		n3.setName("n3");
		n3.setNext(null);
	}
	
	/**
	 * Tests the '{@link linkedlist.Node#find(java.lang.String) <em>Find</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see linkedlist.Node#find(java.lang.String)
	 */
	public void test1_find() {
		if (n1==null || n2==null || n3==null) initNodes();
		assertTrue(n1.find("n1"));
		assertTrue(n2.find("n2"));
		assertTrue(n3.find("n3"));
	}
	
	public void test2_find() {
		if (n1==null || n2==null || n3==null) initNodes();
		assertTrue(n2.find("n3"));
		assertFalse(n3.find("n2"));	
	}

	/**
	 * Tests the '{@link linkedlist.Node#find(java.lang.String) <em>Find</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see linkedlist.Node#find(java.lang.String)
	 */
	public void test1_toString() {
		if (n3==null) initNodes();
		assertTrue("n3".equals(n3.toString()));
		assertFalse("n".equals(n3.toString()));
	}

} //NodeTest
