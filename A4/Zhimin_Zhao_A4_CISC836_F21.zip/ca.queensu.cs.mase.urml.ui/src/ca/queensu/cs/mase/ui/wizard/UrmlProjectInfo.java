package ca.queensu.cs.mase.ui.wizard;

import org.eclipse.xtext.ui.wizard.DefaultProjectInfo;

public class UrmlProjectInfo extends DefaultProjectInfo {
	
}
