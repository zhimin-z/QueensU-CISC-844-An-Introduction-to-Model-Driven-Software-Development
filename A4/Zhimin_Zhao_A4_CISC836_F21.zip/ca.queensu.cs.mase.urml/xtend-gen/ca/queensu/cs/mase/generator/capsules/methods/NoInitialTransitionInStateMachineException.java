package ca.queensu.cs.mase.generator.capsules.methods;

@SuppressWarnings("all")
public class NoInitialTransitionInStateMachineException extends RuntimeException {
}
