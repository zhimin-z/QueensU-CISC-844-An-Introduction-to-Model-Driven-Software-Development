package ca.queensu.cs.mase.types;

public interface Value {

}
