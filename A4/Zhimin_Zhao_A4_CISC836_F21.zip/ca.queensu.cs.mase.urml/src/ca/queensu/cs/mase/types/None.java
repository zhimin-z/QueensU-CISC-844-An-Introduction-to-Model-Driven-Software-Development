package ca.queensu.cs.mase.types;


public class None implements Value {

	@Override
	public String toString() {
		return "None";
	}
}
