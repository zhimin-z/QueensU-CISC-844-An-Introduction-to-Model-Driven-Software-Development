package ca.queensu.cs.mase.util;

public class UrmlInterruptedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
