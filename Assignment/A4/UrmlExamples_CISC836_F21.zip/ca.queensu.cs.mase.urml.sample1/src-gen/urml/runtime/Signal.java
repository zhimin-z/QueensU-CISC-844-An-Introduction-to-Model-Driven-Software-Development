package urml.runtime;
public class Signal {}
