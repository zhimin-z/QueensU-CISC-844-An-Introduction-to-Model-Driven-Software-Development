package urml.runtime;
public class CommonObj {
}
