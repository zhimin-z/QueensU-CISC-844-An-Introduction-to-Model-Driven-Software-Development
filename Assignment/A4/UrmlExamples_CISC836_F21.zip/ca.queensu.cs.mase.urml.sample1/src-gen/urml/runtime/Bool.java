package urml.runtime;
public class Bool extends CommonObj {
	public boolean val;
	public Bool(boolean v) { val = v; }
}
