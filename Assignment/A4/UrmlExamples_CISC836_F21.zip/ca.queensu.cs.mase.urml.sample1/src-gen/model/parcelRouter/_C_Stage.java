package model.parcelRouter;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Stage.
 * @generated
 */
public class _C_Stage extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Stage() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Stage(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList(_p_toSensorController);
		
		externalports = Arrays.asList(_p_goingIn, _p_gettingOutRight, _p_gettingOutLeft, _p_fromTop);
		capsules = Arrays.asList(_ci_chute0, _ci_chute1, _ci_sensorCntl, _ci_switch);
		_ci_chute0.name = "chute0";
		_ci_chute1.name = "chute1";
		_ci_sensorCntl.name = "sensorCntl";
		_ci_switch.name = "switch";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				this, this._p_goingIn,
				
				// capsule 2, port 2
				_ci_chute0, _ci_chute0._p_enter), 
			new Connector(
				// capsule 1, port 1
				_ci_chute0, _ci_chute0._p_leave,
				
				// capsule 2, port 2
				_ci_chute1, _ci_chute1._p_enter), 
			new Connector(
				// capsule 1, port 1
				_ci_chute0, _ci_chute0._p_toControl,
				
				// capsule 2, port 2
				_ci_sensorCntl, _ci_sensorCntl._p_sense), 
			new Connector(
				// capsule 1, port 1
				_ci_chute1, _ci_chute1._p_leave,
				
				// capsule 2, port 2
				_ci_switch, _ci_switch._p_enter), 
			new Connector(
				// capsule 1, port 1
				_ci_chute1, _ci_chute1._p_toControl,
				
				// capsule 2, port 2
				_ci_chute1, _ci_chute1._p_dummy), 
			new Connector(
				// capsule 1, port 1
				_ci_sensorCntl, _ci_sensorCntl._p_setSwitch,
				
				// capsule 2, port 2
				_ci_switch, _ci_switch._p_setSwitch), 
			new Connector(
				// capsule 1, port 1
				_ci_switch, _ci_switch._p_leaveLeft,
				
				// capsule 2, port 2
				this, this._p_gettingOutLeft), 
			new Connector(
				// capsule 1, port 1
				_ci_switch, _ci_switch._p_leaveRight,
				
				// capsule 2, port 2
				this, this._p_gettingOutRight), 
			new Connector(
				// capsule 1, port 1
				this, this._p_toSensorController,
				
				// capsule 2, port 2
				_ci_sensorCntl, _ci_sensorCntl._p_fromStage)
		);
	}
	MessagePort _p_toSensorController = new MessagePort("toSensorController", new _P_LevelNumberProtocol());
	MessagePort _p_goingIn = new MessagePort("goingIn", new _P_ParcelPassage());
	MessagePort _p_gettingOutRight = new MessagePort("gettingOutRight", new _P_ParcelPassage());
	MessagePort _p_gettingOutLeft = new MessagePort("gettingOutLeft", new _P_ParcelPassage());
	MessagePort _p_fromTop = new MessagePort("fromTop", new _P_LevelNumberProtocol());
	_C_Chute _ci_chute0 = new _C_Chute(this);
	_C_Chute _ci_chute1 = new _C_Chute(this);
	_C_SensorController _ci_sensorCntl = new _C_SensorController(this);
	_C_Switch _ci_switch = new _C_Switch(this);
	private int _a_level;
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: setLevelNumber
	 */
	private Transition _tran_setLevelNumber = new Transition(
	
		// name
		"setLevelNumber",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_levelNumber = ((Int) (params.get(0))).val;
			_a_level = _i_levelNumber;passMessage(_p_toSensorController, new Message(
				_p_toSensorController, 
				_P_LevelNumberProtocol._s_sendLevelNumber,
				Arrays.asList(
					new Int(_i_levelNumber)
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_fromTop, _P_LevelNumberProtocol._s_sendLevelNumber
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList(_tran_setLevelNumber);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "setLevelNumber":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_setLevelNumber.action.accept(params);
					currentState = _state_single;
					return false;
				}
			default:
				return false;
		}
	}
}
