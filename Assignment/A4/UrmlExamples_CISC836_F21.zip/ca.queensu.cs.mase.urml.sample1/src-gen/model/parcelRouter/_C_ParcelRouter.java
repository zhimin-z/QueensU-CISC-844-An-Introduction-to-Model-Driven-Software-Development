package model.parcelRouter;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for ParcelRouter.
 * @generated
 */
public class _C_ParcelRouter extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_ParcelRouter() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_ParcelRouter(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList(_p_toStage0, _p_toStage1, _p_toStage2);
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_generator, _ci_stage0, _ci_stage1, _ci_stage2, _ci_bin0, _ci_bin1, _ci_bin2, _ci_bin3);
		_ci_generator.name = "generator";
		_ci_stage0.name = "stage0";
		_ci_stage1.name = "stage1";
		_ci_stage2.name = "stage2";
		_ci_bin0.name = "bin0";
		_ci_bin1.name = "bin1";
		_ci_bin2.name = "bin2";
		_ci_bin3.name = "bin3";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_generator, _ci_generator._p_gettingOut,
				
				// capsule 2, port 2
				_ci_stage0, _ci_stage0._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				_ci_stage0, _ci_stage0._p_gettingOutRight,
				
				// capsule 2, port 2
				_ci_stage1, _ci_stage1._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				_ci_stage0, _ci_stage0._p_gettingOutLeft,
				
				// capsule 2, port 2
				_ci_stage2, _ci_stage2._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				_ci_stage1, _ci_stage1._p_gettingOutRight,
				
				// capsule 2, port 2
				_ci_bin0, _ci_bin0._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				_ci_stage1, _ci_stage1._p_gettingOutLeft,
				
				// capsule 2, port 2
				_ci_bin1, _ci_bin1._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				_ci_stage2, _ci_stage2._p_gettingOutRight,
				
				// capsule 2, port 2
				_ci_bin2, _ci_bin2._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				_ci_stage2, _ci_stage2._p_gettingOutLeft,
				
				// capsule 2, port 2
				_ci_bin3, _ci_bin3._p_goingIn), 
			new Connector(
				// capsule 1, port 1
				this, this._p_toStage0,
				
				// capsule 2, port 2
				_ci_stage0, _ci_stage0._p_fromTop), 
			new Connector(
				// capsule 1, port 1
				this, this._p_toStage1,
				
				// capsule 2, port 2
				_ci_stage1, _ci_stage1._p_fromTop), 
			new Connector(
				// capsule 1, port 1
				this, this._p_toStage2,
				
				// capsule 2, port 2
				_ci_stage2, _ci_stage2._p_fromTop)
		);
	}
	MessagePort _p_toStage0 = new MessagePort("toStage0", new _P_LevelNumberProtocol());
	MessagePort _p_toStage1 = new MessagePort("toStage1", new _P_LevelNumberProtocol());
	MessagePort _p_toStage2 = new MessagePort("toStage2", new _P_LevelNumberProtocol());
	_C_Generator _ci_generator = new _C_Generator(this);
	_C_Stage _ci_stage0 = new _C_Stage(this);
	_C_Stage _ci_stage1 = new _C_Stage(this);
	_C_Stage _ci_stage2 = new _C_Stage(this);
	_C_Bin _ci_bin0 = new _C_Bin(this);
	_C_Bin _ci_bin1 = new _C_Bin(this);
	_C_Bin _ci_bin2 = new _C_Bin(this);
	_C_Bin _ci_bin3 = new _C_Bin(this);
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_toStage0, new Message(
				_p_toStage0, 
				_P_LevelNumberProtocol._s_sendLevelNumber,
				Arrays.asList(
					new Int(1)
				)));
			passMessage(_p_toStage1, new Message(
				_p_toStage1, 
				_P_LevelNumberProtocol._s_sendLevelNumber,
				Arrays.asList(
					new Int(0)
				)));
			passMessage(_p_toStage2, new Message(
				_p_toStage2, 
				_P_LevelNumberProtocol._s_sendLevelNumber,
				Arrays.asList(
					new Int(0)
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList();
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
