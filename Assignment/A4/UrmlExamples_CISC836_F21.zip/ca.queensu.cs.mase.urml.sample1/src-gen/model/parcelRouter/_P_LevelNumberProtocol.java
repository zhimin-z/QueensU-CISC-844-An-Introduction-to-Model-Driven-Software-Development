package model.parcelRouter;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: LevelNumberProtocol
 * @generated
 */
public class _P_LevelNumberProtocol extends Protocol {
	public _P_LevelNumberProtocol() {
		incomingSignals = Arrays.asList();
		outgoingSignals = Arrays.asList(_s_sendLevelNumber);
	}
	public static Signal _s_sendLevelNumber = new Signal();
}
