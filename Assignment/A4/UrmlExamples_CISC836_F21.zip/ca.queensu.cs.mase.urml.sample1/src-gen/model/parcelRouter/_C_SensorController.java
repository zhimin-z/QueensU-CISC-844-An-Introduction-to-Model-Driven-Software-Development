package model.parcelRouter;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for SensorController.
 * @generated
 */
public class _C_SensorController extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_SensorController() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_SensorController(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_sense, _p_setSwitch, _p_fromStage);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_sense = new MessagePort("sense", new _P_ParcelPassage());
	MessagePort _p_setSwitch = new MessagePort("setSwitch", new _P_SensorProtocol());
	MessagePort _p_fromStage = new MessagePort("fromStage", new _P_LevelNumberProtocol());
	private int _a_level;
	public int _f_leftShiftAndBitmask(int _l_destination, int _l_level) {
		int _l_counter = 0;
		while (_l_counter < _l_level) {
			_l_destination = _l_destination / 2;
			_l_counter = _l_counter + 1;
		}
		if (_l_destination % 2 == 1) {
			return 1;
		} else {
			return 0;
		}
	}
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: setLevelNumber
	 */
	private Transition _tran_setLevelNumber = new Transition(
	
		// name
		"setLevelNumber",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_levelNumber = ((Int) (params.get(0))).val;
			_a_level = _i_levelNumber;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_fromStage, _P_LevelNumberProtocol._s_sendLevelNumber
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: senseParcel
	 */
	private Transition _tran_senseParcel = new Transition(
	
		// name
		"senseParcel",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_destination = ((Int) (params.get(0))).val;
			passMessage(_p_setSwitch, new Message(
				_p_setSwitch, 
				_P_SensorProtocol._s_sendDirection,
				Arrays.asList(
					new Bool(_f_leftShiftAndBitmask(_i_destination,_a_level) != 0)
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_sense, _P_ParcelPassage._s_sendParcel
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList(_tran_setLevelNumber, _tran_senseParcel);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "setLevelNumber":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_setLevelNumber.action.accept(params);
					currentState = _state_single;
					return false;
				}
			case "senseParcel":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_senseParcel.action.accept(params);
					currentState = _state_single;
					return false;
				}
			default:
				return false;
		}
	}
}
