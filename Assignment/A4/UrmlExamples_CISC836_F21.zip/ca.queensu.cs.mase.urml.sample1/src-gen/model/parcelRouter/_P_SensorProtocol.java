package model.parcelRouter;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: SensorProtocol
 * @generated
 */
public class _P_SensorProtocol extends Protocol {
	public _P_SensorProtocol() {
		incomingSignals = Arrays.asList();
		outgoingSignals = Arrays.asList(_s_sendDirection);
	}
	public static Signal _s_sendDirection = new Signal();
}
