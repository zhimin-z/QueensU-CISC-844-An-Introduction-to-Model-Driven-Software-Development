package model.parcelRouter;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: ParcelPassage
 * @generated
 */
public class _P_ParcelPassage extends Protocol {
	public _P_ParcelPassage() {
		incomingSignals = Arrays.asList();
		outgoingSignals = Arrays.asList(_s_sendParcel);
	}
	public static Signal _s_sendParcel = new Signal();
}
