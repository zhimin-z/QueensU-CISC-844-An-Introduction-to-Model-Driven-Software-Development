package model.parcelRouter;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Bin.
 * @generated
 */
public class _C_Bin extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Bin() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Bin(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_goingIn);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_goingIn = new MessagePort("goingIn", new _P_ParcelPassage());
	private int _a_numOfParcels = 0;
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: sending
	 */
	private Transition _tran_sending = new Transition(
	
		// name
		"sending",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_designatedBin = ((Int) (params.get(0))).val;
			_a_numOfParcels = _a_numOfParcels + 1;System.out.println(this.name + ": logging to logger with: " + "Bin: a parcel with id " + _i_designatedBin + " has entered bin");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_goingIn, _P_ParcelPassage._s_sendParcel
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList(_tran_sending);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "sending":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_sending.action.accept(params);
					currentState = _state_single;
					return false;
				}
			default:
				return false;
		}
	}
}
