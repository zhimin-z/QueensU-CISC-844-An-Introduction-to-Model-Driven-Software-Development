package model.parcelRouter;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Switch.
 * @generated
 */
public class _C_Switch extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Switch() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Switch(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_setSwitch, _p_enter, _p_leaveLeft, _p_leaveRight);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_setSwitch = new MessagePort("setSwitch", new _P_SensorProtocol());
	MessagePort _p_enter = new MessagePort("enter", new _P_ParcelPassage());
	MessagePort _p_leaveLeft = new MessagePort("leaveLeft", new _P_ParcelPassage());
	MessagePort _p_leaveRight = new MessagePort("leaveRight", new _P_ParcelPassage());
	final TimerPort _tp_timer = new TimerPort();
	private boolean _a_leftNotRight = true;
	private int _a_timeoutPeriod = 2000;
	private int _a_storedParcelDestination = -1;
	/**
	 * A state with name: empty
	 */
	private State _state_empty = new State(
	
		// name
		"empty",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: entered
	 */
	private State _state_entered = new State(
	
		// name
		"entered",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: setDirectionWhileEmpty
	 */
	private Transition _tran_setDirectionWhileEmpty = new Transition(
	
		// name
		"setDirectionWhileEmpty",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			boolean _i_direction = ((Bool) (params.get(0))).val;
			_a_leftNotRight = _i_direction;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_setSwitch, _P_SensorProtocol._s_sendDirection
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: setDirectionWhileEntered
	 */
	private Transition _tran_setDirectionWhileEntered = new Transition(
	
		// name
		"setDirectionWhileEntered",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			boolean _i_direction = ((Bool) (params.get(0))).val;
			_a_leftNotRight = _i_direction;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_setSwitch, _P_SensorProtocol._s_sendDirection
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: parcelEnters
	 */
	private Transition _tran_parcelEnters = new Transition(
	
		// name
		"parcelEnters",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_destination = ((Int) (params.get(0))).val;
			_a_storedParcelDestination = _i_destination;System.out.println(this.name + ": logging to logger with: " + "Switch: parcel entered, sending to " + _i_destination);
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_timeoutPeriod);
			instants.put(_tp_timer, timeoutInstant);}
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_enter, _P_ParcelPassage._s_sendParcel
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: parcelLeaves
	 */
	private Transition _tran_parcelLeaves = new Transition(
	
		// name
		"parcelLeaves",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			if (_a_leftNotRight) {
				passMessage(_p_leaveLeft, new Message(
					_p_leaveLeft, 
					_P_ParcelPassage._s_sendParcel,
					Arrays.asList(
						new Int(_a_storedParcelDestination)
					)));
			} else {
				passMessage(_p_leaveRight, new Message(
					_p_leaveRight, 
					_P_ParcelPassage._s_sendParcel,
					Arrays.asList(
						new Int(_a_storedParcelDestination)
					)));
			}
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_timer
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "empty":
				return Arrays.asList(_tran_setDirectionWhileEmpty, _tran_parcelEnters);
			case "entered":
				return Arrays.asList(_tran_setDirectionWhileEntered, _tran_parcelLeaves);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "setDirectionWhileEmpty":
				if (_state_empty != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_setDirectionWhileEmpty.action.accept(params);
					currentState = _state_empty;
					return false;
				}
			case "setDirectionWhileEntered":
				if (_state_entered != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_setDirectionWhileEntered.action.accept(params);
					currentState = _state_entered;
					return false;
				}
			case "parcelEnters":
				if (_state_empty != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_empty.exit.run();
					_tran_parcelEnters.action.accept(params);
					_state_entered.entry.run();
					currentState = _state_entered;
					return false;
				}
			case "parcelLeaves":
				if (_state_entered != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_entered.exit.run();
					_tran_parcelLeaves.action.accept(params);
					_state_empty.entry.run();
					currentState = _state_empty;
					return false;
				}
			default:
				return false;
		}
	}
}
