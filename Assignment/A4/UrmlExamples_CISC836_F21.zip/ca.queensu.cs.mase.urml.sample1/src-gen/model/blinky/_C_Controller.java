package model.blinky;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Controller.
 * @generated
 */
public class _C_Controller extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Controller() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Controller(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_connectToLight);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_connectToLight = new MessagePort("connectToLight", new _P_ControllerProtocol());
	final TimerPort _tp_blinkingCycleTimer = new TimerPort();
	private int _a_blinkingCyclePeriod = 5000;
	/**
	 * A state with name: on
	 */
	private State _state_on = new State(
	
		// name
		"on",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: off
	 */
	private State _state_off = new State(
	
		// name
		"off",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_blinkingCyclePeriod);
			instants.put(_tp_blinkingCycleTimer, timeoutInstant);}
			passMessage(_p_connectToLight, new Message(
				_p_connectToLight, 
				_P_ControllerProtocol._s_start,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "connect to light start");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: on2off
	 */
	private Transition _tran_on2off = new Transition(
	
		// name
		"on2off",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_blinkingCyclePeriod);
			instants.put(_tp_blinkingCycleTimer, timeoutInstant);}
			passMessage(_p_connectToLight, new Message(
				_p_connectToLight, 
				_P_ControllerProtocol._s_stop,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "Blinky stops blinking for " + _a_blinkingCyclePeriod / 1000 + " seconds");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_blinkingCycleTimer
	);
	/**
	 * A transition with name: off2On
	 */
	private Transition _tran_off2On = new Transition(
	
		// name
		"off2On",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_blinkingCyclePeriod);
			instants.put(_tp_blinkingCycleTimer, timeoutInstant);}
			passMessage(_p_connectToLight, new Message(
				_p_connectToLight, 
				_P_ControllerProtocol._s_start,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "Blinky blinks for " + _a_blinkingCyclePeriod / 1000 + " seconds");
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_blinkingCycleTimer
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "on":
				return Arrays.asList(_tran_on2off);
			case "off":
				return Arrays.asList(_tran_off2On);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "on2off":
				if (_state_on != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_on.exit.run();
					_tran_on2off.action.accept(params);
					_state_off.entry.run();
					currentState = _state_off;
					return false;
				}
			case "off2On":
				if (_state_off != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_off.exit.run();
					_tran_off2On.action.accept(params);
					_state_on.entry.run();
					currentState = _state_on;
					return false;
				}
			default:
				return false;
		}
	}
}
