package model.widgetManufacturing;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Robot.
 * @generated
 */
public class _C_Robot extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Robot() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Robot(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_Robot2CSPort);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_Robot2CSPort = new MessagePort("Robot2CSPort", new _P_RobotProtocol());
	final TimerPort _tp_DeliveryTimer = new TimerPort();
	private int _a_widgetDeliveringTime = 5000;
	/**
	 * A state with name: on
	 */
	private State _state_on = new State(
	
		// name
		"on",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: standby
	 */
	private State _state_standby = new State(
	
		// name
		"standby",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to RobotLog with: " + "Robot: standby");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: delivering
	 */
	private State _state_delivering = new State(
	
		// name
		"delivering",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_widgetDeliveringTime);
			instants.put(_tp_DeliveryTimer, timeoutInstant);}
			System.out.println(this.name + ": logging to RobotLog with: " + "Robot: delivering");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: shutDown
	 */
	private State _state_shutDown = new State(
	
		// name
		"shutDown",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to RobotLog with: " + "Robot: shutDown");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: start
	 */
	private Transition _tran_start = new Transition(
	
		// name
		"start",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_Robot2CSPort, _P_RobotProtocol._s_deliverWidget
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: finished
	 */
	private Transition _tran_finished = new Transition(
	
		// name
		"finished",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_Robot2CSPort, new Message(
				_p_Robot2CSPort, 
				_P_RobotProtocol._s_widgetDelivered,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_DeliveryTimer
	);
	/**
	 * A transition with name: stop1
	 */
	private Transition _tran_stop1 = new Transition(
	
		// name
		"stop1",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_Robot2CSPort, _P_RobotProtocol._s_shutDown
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: stop2
	 */
	private Transition _tran_stop2 = new Transition(
	
		// name
		"stop2",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_Robot2CSPort, _P_RobotProtocol._s_shutDown
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "on":
				return Arrays.asList();
			case "standby":
				return Arrays.asList(_tran_start, _tran_stop1);
			case "delivering":
				return Arrays.asList(_tran_finished, _tran_stop2);
			case "shutDown":
				return Arrays.asList();
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "start":
				if (_state_standby != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_standby.exit.run();
					_tran_start.action.accept(params);
					_state_delivering.entry.run();
					currentState = _state_delivering;
					return false;
				}
			case "finished":
				if (_state_delivering != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_delivering.exit.run();
					_tran_finished.action.accept(params);
					_state_standby.entry.run();
					currentState = _state_standby;
					return false;
				}
			case "stop1":
				if (_state_standby != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_standby.exit.run();
					_state_on.exit.run();
					_tran_stop1.action.accept(params);
					_state_shutDown.entry.run();
					currentState = _state_shutDown;
					return true;
				}
			case "stop2":
				if (_state_delivering != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_delivering.exit.run();
					_state_on.exit.run();
					_tran_stop2.action.accept(params);
					_state_shutDown.entry.run();
					currentState = _state_shutDown;
					return true;
				}
			default:
				return false;
		}
	}
}
