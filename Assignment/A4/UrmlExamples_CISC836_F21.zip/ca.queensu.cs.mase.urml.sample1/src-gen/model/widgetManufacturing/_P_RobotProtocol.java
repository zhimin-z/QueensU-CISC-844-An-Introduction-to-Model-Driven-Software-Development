package model.widgetManufacturing;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: RobotProtocol
 * @generated
 */
public class _P_RobotProtocol extends Protocol {
	public _P_RobotProtocol() {
		incomingSignals = Arrays.asList(_s_widgetDelivered);
		outgoingSignals = Arrays.asList(_s_deliverWidget, _s_shutDown);
	}
	public static Signal _s_widgetDelivered = new Signal();
	public static Signal _s_deliverWidget = new Signal();
	public static Signal _s_shutDown = new Signal();
}
