package model.widgetManufacturing;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for ProductionLine.
 * @generated
 */
public class _C_ProductionLine extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_ProductionLine() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_ProductionLine(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_toWSPort, _p_toobotPort);
		capsules = Arrays.asList(_ci_workstationRef, _ci_robotRef);
		_ci_workstationRef.name = "workstationRef";
		_ci_robotRef.name = "robotRef";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				this, this._p_toWSPort,
				
				// capsule 2, port 2
				_ci_workstationRef, _ci_workstationRef._p_WS2CSPort), 
			new Connector(
				// capsule 1, port 1
				this, this._p_toobotPort,
				
				// capsule 2, port 2
				_ci_robotRef, _ci_robotRef._p_Robot2CSPort)
		);
	}
	MessagePort _p_toWSPort = new MessagePort("toWSPort", new _P_WorkstationProtocol());
	MessagePort _p_toobotPort = new MessagePort("toobotPort", new _P_RobotProtocol());
	_C_Workstation _ci_workstationRef = new _C_Workstation(this);
	_C_Robot _ci_robotRef = new _C_Robot(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
