package model.widgetManufacturing;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for SystemContainer.
 * @generated
 */
public class _C_SystemContainer extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_SystemContainer() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_SystemContainer(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_controlSoftware, _ci_productionLine);
		_ci_controlSoftware.name = "controlSoftware";
		_ci_productionLine.name = "productionLine";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_controlSoftware, _ci_controlSoftware._p_CS2RobotPort,
				
				// capsule 2, port 2
				_ci_productionLine, _ci_productionLine._p_toobotPort), 
			new Connector(
				// capsule 1, port 1
				_ci_controlSoftware, _ci_controlSoftware._p_CS2WSPort,
				
				// capsule 2, port 2
				_ci_productionLine, _ci_productionLine._p_toWSPort)
		);
	}
	_C_ControlSoftware _ci_controlSoftware = new _C_ControlSoftware(this);
	_C_ProductionLine _ci_productionLine = new _C_ProductionLine(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
