package model.widgetManufacturing;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for ControlSoftware.
 * @generated
 */
public class _C_ControlSoftware extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_ControlSoftware() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_ControlSoftware(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_CS2WSPort, _p_CS2RobotPort);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_CS2WSPort = new MessagePort("CS2WSPort", new _P_WorkstationProtocol());
	MessagePort _p_CS2RobotPort = new MessagePort("CS2RobotPort", new _P_RobotProtocol());
	final TimerPort _tp_StartTimer = new TimerPort();
	final TimerPort _tp_StopTimer = new TimerPort();
	private int _a_startUpDelay = 2000;
	private int _a_systemStopTime = 30000;
	/**
	 * A state with name: on
	 */
	private State _state_on = new State(
	
		// name
		"on",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: startup
	 */
	private State _state_startup = new State(
	
		// name
		"startup",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_startUpDelay);
			instants.put(_tp_StartTimer, timeoutInstant);}
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_systemStopTime);
			instants.put(_tp_StopTimer, timeoutInstant);}
			System.out.println(this.name + ": logging to CSLog with: " + "CS: startup");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: produce
	 */
	private State _state_produce = new State(
	
		// name
		"produce",
		
		// entry code
		() -> {
			passMessage(_p_CS2WSPort, new Message(
				_p_CS2WSPort, 
				_P_WorkstationProtocol._s_produceWidget,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to CSLog with: " + "CS: produce");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: deliver
	 */
	private State _state_deliver = new State(
	
		// name
		"deliver",
		
		// entry code
		() -> {
			passMessage(_p_CS2RobotPort, new Message(
				_p_CS2RobotPort, 
				_P_RobotProtocol._s_deliverWidget,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to CSLog with: " + "CS: deliver");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: shutDown
	 */
	private State _state_shutDown = new State(
	
		// name
		"shutDown",
		
		// entry code
		() -> {
			passMessage(_p_CS2WSPort, new Message(
				_p_CS2WSPort, 
				_P_WorkstationProtocol._s_shutDown,
				Arrays.asList(
				)));
			passMessage(_p_CS2RobotPort, new Message(
				_p_CS2RobotPort, 
				_P_RobotProtocol._s_shutDown,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to CSLog with: " + "CS: shutDown");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: start
	 */
	private Transition _tran_start = new Transition(
	
		// name
		"start",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_StartTimer
	);
	/**
	 * A transition with name: deliverMe
	 */
	private Transition _tran_deliverMe = new Transition(
	
		// name
		"deliverMe",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_CS2WSPort, _P_WorkstationProtocol._s_widgetProduced
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: goAgain
	 */
	private Transition _tran_goAgain = new Transition(
	
		// name
		"goAgain",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_CS2RobotPort, _P_RobotProtocol._s_widgetDelivered
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: stop
	 */
	private Transition _tran_stop = new Transition(
	
		// name
		"stop",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_StopTimer
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "on":
				return Arrays.asList(_tran_stop);
			case "startup":
				return Arrays.asList(_tran_start, _tran_stop);
			case "produce":
				return Arrays.asList(_tran_deliverMe, _tran_stop);
			case "deliver":
				return Arrays.asList(_tran_goAgain, _tran_stop);
			case "shutDown":
				return Arrays.asList();
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "start":
				if (_state_startup != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_startup.exit.run();
					_tran_start.action.accept(params);
					_state_produce.entry.run();
					currentState = _state_produce;
					return false;
				}
			case "deliverMe":
				if (_state_produce != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_produce.exit.run();
					_tran_deliverMe.action.accept(params);
					_state_deliver.entry.run();
					currentState = _state_deliver;
					return false;
				}
			case "goAgain":
				if (_state_deliver != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_deliver.exit.run();
					_tran_goAgain.action.accept(params);
					_state_produce.entry.run();
					currentState = _state_produce;
					return false;
				}
			case "stop":
				if (_state_on != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_on.exit.run();
					_tran_stop.action.accept(params);
					_state_shutDown.entry.run();
					currentState = _state_shutDown;
					return true;
				}
			default:
				return false;
		}
	}
}
