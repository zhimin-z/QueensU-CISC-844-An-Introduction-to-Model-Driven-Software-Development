package model.diningPhilosophers;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Philosopher.
 * @generated
 */
public class _C_Philosopher extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Philosopher() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Philosopher(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_left, _p_right, _p_signer);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_left = new MessagePort("left", new _P_PhilosopherForkProtocol());
	MessagePort _p_right = new MessagePort("right", new _P_PhilosopherForkProtocol());
	MessagePort _p_signer = new MessagePort("signer", new _P_RingPhilosopherProtocol());
	final TimerPort _tp_eatTimer = new TimerPort();
	final TimerPort _tp_thinkTimer = new TimerPort();
	final TimerPort _tp_delayTimer = new TimerPort();
	private int _a_id = -1;
	private int _a_delayTimeout = 300;
	private int _a_eatTimeout = 600;
	private int _a_thinkTimeout = 600;
	public boolean _f_isEvenPhil() {
		return _a_id % 2 == 0;
	}
	public void _f_setID(int _l_id_) {
		_a_id = _l_id_;
	}
	/**
	 * A state with name: start
	 */
	private State _state_start = new State(
	
		// name
		"start",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: delay
	 */
	private State _state_delay = new State(
	
		// name
		"delay",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_delayTimeout * _a_id);
			instants.put(_tp_delayTimer, timeoutInstant);}
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: think
	 */
	private State _state_think = new State(
	
		// name
		"think",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_thinkTimeout);
			instants.put(_tp_thinkTimer, timeoutInstant);}
			System.out.println(this.name + ": logging to logger with: " + "thinking...");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: pickingUpFirstFork
	 */
	private State _state_pickingUpFirstFork = new State(
	
		// name
		"pickingUpFirstFork",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "picking up the first fork");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: gotFirstFork
	 */
	private State _state_gotFirstFork = new State(
	
		// name
		"gotFirstFork",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "got the first fork");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: pickingUpSecondFork
	 */
	private State _state_pickingUpSecondFork = new State(
	
		// name
		"pickingUpSecondFork",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "picking up the second fork");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: gotSecondFork
	 */
	private State _state_gotSecondFork = new State(
	
		// name
		"gotSecondFork",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "got the second fork");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: eating
	 */
	private State _state_eating = new State(
	
		// name
		"eating",
		
		// entry code
		() -> {
			{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_eatTimeout);
			instants.put(_tp_eatTimer, timeoutInstant);}
			System.out.println(this.name + ": logging to logger with: " + "eating... om nom nom");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: puttingDownFirstFork
	 */
	private State _state_puttingDownFirstFork = new State(
	
		// name
		"puttingDownFirstFork",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "putting down the first fork");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: puttingDownSecondFork
	 */
	private State _state_puttingDownSecondFork = new State(
	
		// name
		"puttingDownSecondFork",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "putting down the second fork");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: setPhilID
	 */
	private Transition _tran_setPhilID = new Transition(
	
		// name
		"setPhilID",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_num = ((Int) (params.get(0))).val;
			_f_setID(_i_num);
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_signer, _P_RingPhilosopherProtocol._s_sign
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: startToThink
	 */
	private Transition _tran_startToThink = new Transition(
	
		// name
		"startToThink",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_delayTimer
	);
	/**
	 * A transition with name: pickUpFirstFork
	 */
	private Transition _tran_pickUpFirstFork = new Transition(
	
		// name
		"pickUpFirstFork",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			if (_f_isEvenPhil()) {
				passMessage(_p_right, new Message(
					_p_right, 
					_P_PhilosopherForkProtocol._s_up,
					Arrays.asList(
					)));
			} else {
				passMessage(_p_left, new Message(
					_p_left, 
					_P_PhilosopherForkProtocol._s_up,
					Arrays.asList(
					)));
			}
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_thinkTimer
	);
	/**
	 * A transition with name: waitAckFromFirstFork
	 */
	private Transition _tran_waitAckFromFirstFork = new Transition(
	
		// name
		"waitAckFromFirstFork",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_ack
			),
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_ack
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: pickUpSecondFork
	 */
	private Transition _tran_pickUpSecondFork = new Transition(
	
		// name
		"pickUpSecondFork",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			if (_f_isEvenPhil()) {
				passMessage(_p_left, new Message(
					_p_left, 
					_P_PhilosopherForkProtocol._s_up,
					Arrays.asList(
					)));
			} else {
				passMessage(_p_right, new Message(
					_p_right, 
					_P_PhilosopherForkProtocol._s_up,
					Arrays.asList(
					)));
			}
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: waitAckFromSecondFork
	 */
	private Transition _tran_waitAckFromSecondFork = new Transition(
	
		// name
		"waitAckFromSecondFork",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_left, _P_PhilosopherForkProtocol._s_ack
			),
			new TriggerIn(
				_p_right, _P_PhilosopherForkProtocol._s_ack
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: goEat
	 */
	private Transition _tran_goEat = new Transition(
	
		// name
		"goEat",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: putDownFirstFork
	 */
	private Transition _tran_putDownFirstFork = new Transition(
	
		// name
		"putDownFirstFork",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_left, new Message(
				_p_left, 
				_P_PhilosopherForkProtocol._s_down,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_eatTimer
	);
	/**
	 * A transition with name: putDownSecondFork
	 */
	private Transition _tran_putDownSecondFork = new Transition(
	
		// name
		"putDownSecondFork",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_right, new Message(
				_p_right, 
				_P_PhilosopherForkProtocol._s_down,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: goThink
	 */
	private Transition _tran_goThink = new Transition(
	
		// name
		"goThink",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "start":
				return Arrays.asList(_tran_setPhilID);
			case "delay":
				return Arrays.asList(_tran_startToThink);
			case "think":
				return Arrays.asList(_tran_pickUpFirstFork);
			case "pickingUpFirstFork":
				return Arrays.asList(_tran_waitAckFromFirstFork);
			case "gotFirstFork":
				return Arrays.asList(_tran_pickUpSecondFork);
			case "pickingUpSecondFork":
				return Arrays.asList(_tran_waitAckFromSecondFork);
			case "gotSecondFork":
				return Arrays.asList(_tran_goEat);
			case "eating":
				return Arrays.asList(_tran_putDownFirstFork);
			case "puttingDownFirstFork":
				return Arrays.asList(_tran_putDownSecondFork);
			case "puttingDownSecondFork":
				return Arrays.asList(_tran_goThink);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "setPhilID":
				if (_state_start != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_start.exit.run();
					_tran_setPhilID.action.accept(params);
					_state_delay.entry.run();
					currentState = _state_delay;
					return false;
				}
			case "startToThink":
				if (_state_delay != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_delay.exit.run();
					_tran_startToThink.action.accept(params);
					_state_think.entry.run();
					currentState = _state_think;
					return false;
				}
			case "pickUpFirstFork":
				if (_state_think != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_think.exit.run();
					_tran_pickUpFirstFork.action.accept(params);
					_state_pickingUpFirstFork.entry.run();
					currentState = _state_pickingUpFirstFork;
					return false;
				}
			case "waitAckFromFirstFork":
				if (_state_pickingUpFirstFork != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_pickingUpFirstFork.exit.run();
					_tran_waitAckFromFirstFork.action.accept(params);
					_state_gotFirstFork.entry.run();
					currentState = _state_gotFirstFork;
					return false;
				}
			case "pickUpSecondFork":
				if (_state_gotFirstFork != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_gotFirstFork.exit.run();
					_tran_pickUpSecondFork.action.accept(params);
					_state_pickingUpSecondFork.entry.run();
					currentState = _state_pickingUpSecondFork;
					return false;
				}
			case "waitAckFromSecondFork":
				if (_state_pickingUpSecondFork != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_pickingUpSecondFork.exit.run();
					_tran_waitAckFromSecondFork.action.accept(params);
					_state_gotSecondFork.entry.run();
					currentState = _state_gotSecondFork;
					return false;
				}
			case "goEat":
				if (_state_gotSecondFork != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_gotSecondFork.exit.run();
					_tran_goEat.action.accept(params);
					_state_eating.entry.run();
					currentState = _state_eating;
					return false;
				}
			case "putDownFirstFork":
				if (_state_eating != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_eating.exit.run();
					_tran_putDownFirstFork.action.accept(params);
					_state_puttingDownFirstFork.entry.run();
					currentState = _state_puttingDownFirstFork;
					return false;
				}
			case "putDownSecondFork":
				if (_state_puttingDownFirstFork != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_puttingDownFirstFork.exit.run();
					_tran_putDownSecondFork.action.accept(params);
					_state_puttingDownSecondFork.entry.run();
					currentState = _state_puttingDownSecondFork;
					return false;
				}
			case "goThink":
				if (_state_puttingDownSecondFork != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_puttingDownSecondFork.exit.run();
					_tran_goThink.action.accept(params);
					_state_think.entry.run();
					currentState = _state_think;
					return false;
				}
			default:
				return false;
		}
	}
}
