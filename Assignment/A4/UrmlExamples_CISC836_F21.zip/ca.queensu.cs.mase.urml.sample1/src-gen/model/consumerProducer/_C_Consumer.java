package model.consumerProducer;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Consumer.
 * @generated
 */
public class _C_Consumer extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Consumer() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Consumer(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_toGet);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_toGet = new MessagePort("toGet", new _P_BufferProtocol());
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: _noname_0
	 */
	private Transition _tran__noname_0 = new Transition(
	
		// name
		"_noname_0",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: _noname_1
	 */
	private Transition _tran__noname_1 = new Transition(
	
		// name
		"_noname_1",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_toDisplay = ((Int) (params.get(0))).val;
			System.out.println(this.name + ": logging to logger with: " + _i_toDisplay);
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_toGet, _P_BufferProtocol._s_get
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList(_tran__noname_1);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "_noname_1":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran__noname_1.action.accept(params);
					currentState = _state_single;
					return false;
				}
			default:
				return false;
		}
	}
}
