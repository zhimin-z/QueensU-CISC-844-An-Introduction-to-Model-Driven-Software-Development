package model.handshake;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Receiver.
 * @generated
 */
public class _C_Receiver extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Receiver() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Receiver(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_hand);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_hand = new MessagePort("hand", new _P_HandshakeProtocol());
	/**
	 * A state with name: start
	 */
	private State _state_start = new State(
	
		// name
		"start",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: end
	 */
	private State _state_end = new State(
	
		// name
		"end",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: receiveHandshake
	 */
	private Transition _tran_receiveHandshake = new Transition(
	
		// name
		"receiveHandshake",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			System.out.println(this.name + ": logging to logger with: " + "received a handshake");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_hand, _P_HandshakeProtocol._s_shake
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "start":
				return Arrays.asList(_tran_receiveHandshake);
			case "end":
				return Arrays.asList();
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "receiveHandshake":
				if (_state_start != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_start.exit.run();
					_tran_receiveHandshake.action.accept(params);
					_state_end.entry.run();
					currentState = _state_end;
					return true;
				}
			default:
				return false;
		}
	}
}
