package model.readersWriters;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Reader.
 * @generated
 */
public class _C_Reader extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Reader() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Reader(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_con, _p_read);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_con = new MessagePort("con", new _P_ControllerRW());
	MessagePort _p_read = new MessagePort("read", new _P_ReadAndWriteThings());
	final TimerPort _tp_timer = new TimerPort();
	private boolean _a_readRequestSent = false;
	private int _a_timeoutPeriod = 200;
	/**
	 * A state with name: notReading
	 */
	private State _state_notReading = new State(
	
		// name
		"notReading",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: reading
	 */
	private State _state_reading = new State(
	
		// name
		"reading",
		
		// entry code
		() -> {
			passMessage(_p_read, new Message(
				_p_read, 
				_P_ReadAndWriteThings._s_read,
				Arrays.asList(
				)));
			System.out.println(this.name + ": logging to logger with: " + "");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: getReading
	 */
	private Transition _tran_getReading = new Transition(
	
		// name
		"getReading",
		
		// guard
		() -> {
			return _a_readRequestSent == false;
		},
		
		// action code
		params -> {
			passMessage(_p_con, new Message(
				_p_con, 
				_P_ControllerRW._s_acquireRead,
				Arrays.asList(
				)));
			_a_readRequestSent = true;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: goReading
	 */
	private Transition _tran_goReading = new Transition(
	
		// name
		"goReading",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			System.out.println(this.name + ": logging to logger with: " + "goReading");
			_a_readRequestSent = false;{java.time.Instant timeoutInstant = java.time.Instant.now().plusMillis(_a_timeoutPeriod);
			instants.put(_tp_timer, timeoutInstant);}
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_con, _P_ControllerRW._s_acknowledge
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: backToNotReading
	 */
	private Transition _tran_backToNotReading = new Transition(
	
		// name
		"backToNotReading",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			passMessage(_p_con, new Message(
				_p_con, 
				_P_ControllerRW._s_releaseRead,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		_tp_timer
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "notReading":
				return Arrays.asList(_tran_getReading, _tran_goReading);
			case "reading":
				return Arrays.asList(_tran_backToNotReading);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "getReading":
				if (_state_notReading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_getReading.action.accept(params);
					currentState = _state_notReading;
					return false;
				}
			case "goReading":
				if (_state_notReading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_notReading.exit.run();
					_tran_goReading.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "backToNotReading":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_reading.exit.run();
					_tran_backToNotReading.action.accept(params);
					_state_notReading.entry.run();
					currentState = _state_notReading;
					return false;
				}
			default:
				return false;
		}
	}
}
