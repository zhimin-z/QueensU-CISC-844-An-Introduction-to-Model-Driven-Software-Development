package model.readersWriters;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Controller.
 * @generated
 */
public class _C_Controller extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Controller() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Controller(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_r0, _p_r1, _p_r2, _p_w0, _p_w1);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_r0 = new MessagePort("r0", new _P_ControllerRW());
	MessagePort _p_r1 = new MessagePort("r1", new _P_ControllerRW());
	MessagePort _p_r2 = new MessagePort("r2", new _P_ControllerRW());
	MessagePort _p_w0 = new MessagePort("w0", new _P_ControllerRW());
	MessagePort _p_w1 = new MessagePort("w1", new _P_ControllerRW());
	private int _a_readers = 0;
	private boolean _a_writing = false;
	private boolean _a_w0waiting = false;
	private boolean _a_w1waiting = false;
	private boolean _a_r0waiting = false;
	private boolean _a_r1waiting = false;
	private boolean _a_r2waiting = false;
	/**
	 * A state with name: none
	 */
	private State _state_none = new State(
	
		// name
		"none",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: writing
	 */
	private State _state_writing = new State(
	
		// name
		"writing",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "CONTROLLER WRITING");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A state with name: reading
	 */
	private State _state_reading = new State(
	
		// name
		"reading",
		
		// entry code
		() -> {
			System.out.println(this.name + ": logging to logger with: " + "CONTROLLER READING");
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedWriteW0
	 */
	private Transition _tran_askedWriteW0 = new Transition(
	
		// name
		"askedWriteW0",
		
		// guard
		() -> {
			return _a_readers == 0 && !_a_writing;
		},
		
		// action code
		params -> {
			_a_writing = true;System.out.println(this.name + ": logging to logger with: " + "acquire write W0");
			passMessage(_p_w0, new Message(
				_p_w0, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w0, _P_ControllerRW._s_acquireWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedWriteW0A
	 */
	private Transition _tran_askedWriteW0A = new Transition(
	
		// name
		"askedWriteW0A",
		
		// guard
		() -> {
			return _a_readers == 0 && !_a_writing && _a_w0waiting;
		},
		
		// action code
		params -> {
			_a_writing = true;passMessage(_p_w0, new Message(
				_p_w0, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
			_a_w0waiting = false;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedWriteW1
	 */
	private Transition _tran_askedWriteW1 = new Transition(
	
		// name
		"askedWriteW1",
		
		// guard
		() -> {
			return _a_readers == 0 && !_a_writing;
		},
		
		// action code
		params -> {
			_a_writing = true;System.out.println(this.name + ": logging to logger with: " + "acquire write W1");
			passMessage(_p_w1, new Message(
				_p_w1, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w1, _P_ControllerRW._s_acquireWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedWriteW1A
	 */
	private Transition _tran_askedWriteW1A = new Transition(
	
		// name
		"askedWriteW1A",
		
		// guard
		() -> {
			return _a_readers == 0 && !_a_writing && _a_w1waiting;
		},
		
		// action code
		params -> {
			_a_writing = true;passMessage(_p_w1, new Message(
				_p_w1, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
			_a_w1waiting = false;
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedReadR0
	 */
	private Transition _tran_askedReadR0 = new Transition(
	
		// name
		"askedReadR0",
		
		// guard
		() -> {
			return _a_writing == false;
		},
		
		// action code
		params -> {
			_a_readers = 1;System.out.println(this.name + ": logging to logger with: " + "acquire read R0");
			passMessage(_p_r0, new Message(
				_p_r0, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r0, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedReadR1
	 */
	private Transition _tran_askedReadR1 = new Transition(
	
		// name
		"askedReadR1",
		
		// guard
		() -> {
			return _a_writing == false;
		},
		
		// action code
		params -> {
			_a_readers = 1;System.out.println(this.name + ": logging to logger with: " + "acquire read R1");
			passMessage(_p_r1, new Message(
				_p_r1, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r1, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedReadR2
	 */
	private Transition _tran_askedReadR2 = new Transition(
	
		// name
		"askedReadR2",
		
		// guard
		() -> {
			return _a_writing == false;
		},
		
		// action code
		params -> {
			_a_readers = 1;System.out.println(this.name + ": logging to logger with: " + "acquire read R2 with one reader");
			passMessage(_p_r2, new Message(
				_p_r2, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r2, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedReadR0A
	 */
	private Transition _tran_askedReadR0A = new Transition(
	
		// name
		"askedReadR0A",
		
		// guard
		() -> {
			return !_a_writing && _a_r0waiting;
		},
		
		// action code
		params -> {
			_a_readers = 1;_a_r0waiting = false;System.out.println(this.name + ": logging to logger with: " + "acquire read R0 with one reader");
			passMessage(_p_r0, new Message(
				_p_r0, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedReadR1A
	 */
	private Transition _tran_askedReadR1A = new Transition(
	
		// name
		"askedReadR1A",
		
		// guard
		() -> {
			return !_a_writing && _a_r1waiting;
		},
		
		// action code
		params -> {
			_a_readers = 1;_a_r1waiting = false;System.out.println(this.name + ": logging to logger with: " + "acquire read R1 with one reader");
			passMessage(_p_r1, new Message(
				_p_r1, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: askedReadR2A
	 */
	private Transition _tran_askedReadR2A = new Transition(
	
		// name
		"askedReadR2A",
		
		// guard
		() -> {
			return !_a_writing && _a_r2waiting;
		},
		
		// action code
		params -> {
			_a_readers = 1;_a_r2waiting = false;System.out.println(this.name + ": logging to logger with: " + "acquire read R2 with one reader");
			passMessage(_p_r2, new Message(
				_p_r2, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleAskedReaderR0
	 */
	private Transition _tran_multipleAskedReaderR0 = new Transition(
	
		// name
		"multipleAskedReaderR0",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers + 1;System.out.println(this.name + ": logging to logger with: " + "acquire read R0 with " + _a_readers + " readers");
			passMessage(_p_r0, new Message(
				_p_r0, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r0, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleAskedReaderR1
	 */
	private Transition _tran_multipleAskedReaderR1 = new Transition(
	
		// name
		"multipleAskedReaderR1",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers + 1;System.out.println(this.name + ": logging to logger with: " + "acquire read R1 with " + _a_readers + " readers");
			passMessage(_p_r1, new Message(
				_p_r1, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r1, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleAskedReaderR2
	 */
	private Transition _tran_multipleAskedReaderR2 = new Transition(
	
		// name
		"multipleAskedReaderR2",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers + 1;System.out.println(this.name + ": logging to logger with: " + "acquire read R2 with " + _a_readers + " readers");
			passMessage(_p_r2, new Message(
				_p_r2, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r2, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleAskedReaderR0A
	 */
	private Transition _tran_multipleAskedReaderR0A = new Transition(
	
		// name
		"multipleAskedReaderR0A",
		
		// guard
		() -> {
			return _a_r0waiting;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers + 1;_a_r0waiting = false;System.out.println(this.name + ": logging to logger with: " + "acquire read R0 with " + _a_readers + " readers");
			passMessage(_p_r0, new Message(
				_p_r0, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleAskedReaderR1A
	 */
	private Transition _tran_multipleAskedReaderR1A = new Transition(
	
		// name
		"multipleAskedReaderR1A",
		
		// guard
		() -> {
			return _a_r1waiting;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers + 1;_a_r1waiting = false;System.out.println(this.name + ": logging to logger with: " + "acquire read R1 with " + _a_readers + " readers");
			passMessage(_p_r1, new Message(
				_p_r1, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleAskedReaderR2A
	 */
	private Transition _tran_multipleAskedReaderR2A = new Transition(
	
		// name
		"multipleAskedReaderR2A",
		
		// guard
		() -> {
			return _a_r2waiting;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers + 1;_a_r2waiting = false;System.out.println(this.name + ": logging to logger with: " + "acquire read R2 with " + _a_readers + " readers");
			passMessage(_p_r2, new Message(
				_p_r2, 
				_P_ControllerRW._s_acknowledge,
				Arrays.asList(
				)));
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: w0requestR
	 */
	private Transition _tran_w0requestR = new Transition(
	
		// name
		"w0requestR",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_w0waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w0, _P_ControllerRW._s_acquireWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: w0requestW
	 */
	private Transition _tran_w0requestW = new Transition(
	
		// name
		"w0requestW",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_w0waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w0, _P_ControllerRW._s_acquireWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: w1requestR
	 */
	private Transition _tran_w1requestR = new Transition(
	
		// name
		"w1requestR",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_w1waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w1, _P_ControllerRW._s_acquireWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: w1requestW
	 */
	private Transition _tran_w1requestW = new Transition(
	
		// name
		"w1requestW",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_w1waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w1, _P_ControllerRW._s_acquireWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: r0request
	 */
	private Transition _tran_r0request = new Transition(
	
		// name
		"r0request",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_r0waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r0, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: r1request
	 */
	private Transition _tran_r1request = new Transition(
	
		// name
		"r1request",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_r1waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r1, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: r2request
	 */
	private Transition _tran_r2request = new Transition(
	
		// name
		"r2request",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_r2waiting = true;
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r2, _P_ControllerRW._s_acquireRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: releaseWrite
	 */
	private Transition _tran_releaseWrite = new Transition(
	
		// name
		"releaseWrite",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			_a_writing = false;System.out.println(this.name + ": logging to logger with: " + "release write");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_w0, _P_ControllerRW._s_releaseWrite
			),
			new TriggerIn(
				_p_w1, _P_ControllerRW._s_releaseWrite
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: multipleReleaseRead
	 */
	private Transition _tran_multipleReleaseRead = new Transition(
	
		// name
		"multipleReleaseRead",
		
		// guard
		() -> {
			return _a_readers > 1;
		},
		
		// action code
		params -> {
			_a_readers = _a_readers - 1;System.out.println(this.name + ": logging to logger with: " + "release read with " + _a_readers + " readers remaining");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r0, _P_ControllerRW._s_releaseRead
			),
			new TriggerIn(
				_p_r1, _P_ControllerRW._s_releaseRead
			),
			new TriggerIn(
				_p_r2, _P_ControllerRW._s_releaseRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: releaseRead
	 */
	private Transition _tran_releaseRead = new Transition(
	
		// name
		"releaseRead",
		
		// guard
		() -> {
			return _a_readers == 1;
		},
		
		// action code
		params -> {
			_a_readers = 0;System.out.println(this.name + ": logging to logger with: " + "release read with no readers remaining");
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_r0, _P_ControllerRW._s_releaseRead
			),
			new TriggerIn(
				_p_r1, _P_ControllerRW._s_releaseRead
			),
			new TriggerIn(
				_p_r2, _P_ControllerRW._s_releaseRead
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "none":
				return Arrays.asList(_tran_askedWriteW0, _tran_askedWriteW0A, _tran_askedWriteW1, _tran_askedWriteW1A, _tran_askedReadR0, _tran_askedReadR1, _tran_askedReadR2, _tran_askedReadR0A, _tran_askedReadR1A, _tran_askedReadR2A);
			case "writing":
				return Arrays.asList(_tran_w0requestW, _tran_w1requestW, _tran_r0request, _tran_r1request, _tran_r2request, _tran_releaseWrite);
			case "reading":
				return Arrays.asList(_tran_multipleAskedReaderR0, _tran_multipleAskedReaderR1, _tran_multipleAskedReaderR2, _tran_multipleAskedReaderR0A, _tran_multipleAskedReaderR1A, _tran_multipleAskedReaderR2A, _tran_w0requestR, _tran_w1requestR, _tran_multipleReleaseRead, _tran_releaseRead);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "askedWriteW0":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedWriteW0.action.accept(params);
					_state_writing.entry.run();
					currentState = _state_writing;
					return false;
				}
			case "askedWriteW0A":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedWriteW0A.action.accept(params);
					_state_writing.entry.run();
					currentState = _state_writing;
					return false;
				}
			case "askedWriteW1":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedWriteW1.action.accept(params);
					_state_writing.entry.run();
					currentState = _state_writing;
					return false;
				}
			case "askedWriteW1A":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedWriteW1A.action.accept(params);
					_state_writing.entry.run();
					currentState = _state_writing;
					return false;
				}
			case "askedReadR0":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedReadR0.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "askedReadR1":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedReadR1.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "askedReadR2":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedReadR2.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "askedReadR0A":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedReadR0A.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "askedReadR1A":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedReadR1A.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "askedReadR2A":
				if (_state_none != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_none.exit.run();
					_tran_askedReadR2A.action.accept(params);
					_state_reading.entry.run();
					currentState = _state_reading;
					return false;
				}
			case "multipleAskedReaderR0":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleAskedReaderR0.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "multipleAskedReaderR1":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleAskedReaderR1.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "multipleAskedReaderR2":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleAskedReaderR2.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "multipleAskedReaderR0A":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleAskedReaderR0A.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "multipleAskedReaderR1A":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleAskedReaderR1A.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "multipleAskedReaderR2A":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleAskedReaderR2A.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "w0requestR":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_w0requestR.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "w0requestW":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_w0requestW.action.accept(params);
					currentState = _state_writing;
					return false;
				}
			case "w1requestR":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_w1requestR.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "w1requestW":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_w1requestW.action.accept(params);
					currentState = _state_writing;
					return false;
				}
			case "r0request":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_r0request.action.accept(params);
					currentState = _state_writing;
					return false;
				}
			case "r1request":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_r1request.action.accept(params);
					currentState = _state_writing;
					return false;
				}
			case "r2request":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_r2request.action.accept(params);
					currentState = _state_writing;
					return false;
				}
			case "releaseWrite":
				if (_state_writing != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_writing.exit.run();
					_tran_releaseWrite.action.accept(params);
					_state_none.entry.run();
					currentState = _state_none;
					return false;
				}
			case "multipleReleaseRead":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_multipleReleaseRead.action.accept(params);
					currentState = _state_reading;
					return false;
				}
			case "releaseRead":
				if (_state_reading != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_state_reading.exit.run();
					_tran_releaseRead.action.accept(params);
					_state_none.entry.run();
					currentState = _state_none;
					return false;
				}
			default:
				return false;
		}
	}
}
