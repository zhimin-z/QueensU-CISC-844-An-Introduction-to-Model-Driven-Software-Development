package model.readersWriters;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Database.
 * @generated
 */
public class _C_Database extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Database() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Database(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList(_p_read, _p_write);
		capsules = Arrays.asList();
		connectors = Arrays.asList(
		);
	}
	MessagePort _p_read = new MessagePort("read", new _P_ReadAndWriteThings());
	MessagePort _p_write = new MessagePort("write", new _P_ReadAndWriteThings());
	private int _a_thing = 1;
	/**
	 * A state with name: single
	 */
	private State _state_single = new State(
	
		// name
		"single",
		
		// entry code
		() -> {
		},
		
		// exit code
		() -> {
		});
	/**
	 * A transition with name: init
	 */
	private Transition _tran_init = new Transition(
	
		// name
		"init",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
		},
		
		// triggers
		Arrays.asList(
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: readData
	 */
	private Transition _tran_readData = new Transition(
	
		// name
		"readData",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			System.out.println(this.name + ": logging to logger with: " + "read: " + _a_thing);
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_read, _P_ReadAndWriteThings._s_read
			)
		),
		
		// timer port
		null
	);
	/**
	 * A transition with name: writeData
	 */
	private Transition _tran_writeData = new Transition(
	
		// name
		"writeData",
		
		// guard
		() -> {
			return true;
		},
		
		// action code
		params -> {
			int _i_data = ((Int) (params.get(0))).val;
			System.out.println(this.name + ": logging to logger with: " + "original: " + _a_thing);
			_a_thing = _i_data;System.out.println(this.name + ": logging to logger with: " + "modified: " + _a_thing);
		},
		
		// triggers
		Arrays.asList(
			new TriggerIn(
				_p_write, _P_ReadAndWriteThings._s_write
			)
		),
		
		// timer port
		null
	);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			case "single":
				return Arrays.asList(_tran_readData, _tran_writeData);
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			case "readData":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_readData.action.accept(params);
					currentState = _state_single;
					return false;
				}
			case "writeData":
				if (_state_single != currentState)
					throw new CurrentStateIsNotSourceStateInTransitionException();
				synchronized (lock) {
					_tran_writeData.action.accept(params);
					currentState = _state_single;
					return false;
				}
			default:
				return false;
		}
	}
}
