package model.readersWriters;
import urml.runtime.*;
import java.util.*;
/**
 * Protocol with name: ReadAndWriteThings
 * @generated
 */
public class _P_ReadAndWriteThings extends Protocol {
	public _P_ReadAndWriteThings() {
		incomingSignals = Arrays.asList();
		outgoingSignals = Arrays.asList(_s_read, _s_write);
	}
	public static Signal _s_read = new Signal();
	public static Signal _s_write = new Signal();
}
