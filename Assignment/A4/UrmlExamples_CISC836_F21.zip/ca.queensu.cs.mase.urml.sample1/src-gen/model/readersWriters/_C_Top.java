package model.readersWriters;
import java.util.*;
import urml.runtime.*;
/**
 * The capsule class for Top.
 * @generated
 */
public class _C_Top extends Capsule {
	/**
	 * Call this constructor when the capsule is a root
	 */
	public _C_Top() {
		this(null);
	}
	
	/**
	 * Call this constructor when the capsule is not a
	 * root
	 * @param parent_ the parent of the capsule
	 */
	public _C_Top(Capsule parent) {
		this.parent = parent;
		internalports = Arrays.asList();
		
		externalports = Arrays.asList();
		capsules = Arrays.asList(_ci_r0, _ci_r1, _ci_r2, _ci_w0, _ci_w1, _ci_c, _ci_db);
		_ci_r0.name = "r0";
		_ci_r1.name = "r1";
		_ci_r2.name = "r2";
		_ci_w0.name = "w0";
		_ci_w1.name = "w1";
		_ci_c.name = "c";
		_ci_db.name = "db";
		connectors = Arrays.asList(
			new Connector(
				// capsule 1, port 1
				_ci_r0, _ci_r0._p_con,
				
				// capsule 2, port 2
				_ci_c, _ci_c._p_r0), 
			new Connector(
				// capsule 1, port 1
				_ci_r1, _ci_r1._p_con,
				
				// capsule 2, port 2
				_ci_c, _ci_c._p_r1), 
			new Connector(
				// capsule 1, port 1
				_ci_r2, _ci_r2._p_con,
				
				// capsule 2, port 2
				_ci_c, _ci_c._p_r2), 
			new Connector(
				// capsule 1, port 1
				_ci_w0, _ci_w0._p_con,
				
				// capsule 2, port 2
				_ci_c, _ci_c._p_w0), 
			new Connector(
				// capsule 1, port 1
				_ci_w1, _ci_w1._p_con,
				
				// capsule 2, port 2
				_ci_c, _ci_c._p_w1), 
			new Connector(
				// capsule 1, port 1
				_ci_r0, _ci_r0._p_read,
				
				// capsule 2, port 2
				_ci_db, _ci_db._p_read), 
			new Connector(
				// capsule 1, port 1
				_ci_r1, _ci_r1._p_read,
				
				// capsule 2, port 2
				_ci_db, _ci_db._p_read), 
			new Connector(
				// capsule 1, port 1
				_ci_r2, _ci_r2._p_read,
				
				// capsule 2, port 2
				_ci_db, _ci_db._p_read), 
			new Connector(
				// capsule 1, port 1
				_ci_w0, _ci_w0._p_write,
				
				// capsule 2, port 2
				_ci_db, _ci_db._p_write), 
			new Connector(
				// capsule 1, port 1
				_ci_w1, _ci_w1._p_write,
				
				// capsule 2, port 2
				_ci_db, _ci_db._p_write)
		);
	}
	_C_Reader _ci_r0 = new _C_Reader(this);
	_C_Reader _ci_r1 = new _C_Reader(this);
	_C_Reader _ci_r2 = new _C_Reader(this);
	_C_Writer _ci_w0 = new _C_Writer(this);
	_C_Writer _ci_w1 = new _C_Writer(this);
	_C_Controller _ci_c = new _C_Controller(this);
	_C_Database _ci_db = new _C_Database(this);
	/**
	 * Find the possible next transitions for each state
	 * @return outgoing transition for the current state
	 */
	public List<? extends Transition> findPossibleTrans() {
		switch (currentState.name) {
			default:
				return new ArrayList<>();
		}
	}
	/**
	 * Initial transition chain
	 */
	public void startInit() {
		synchronized (lock) {
		}
	}
	/**
	 * Executes the transition t and returns whether the
	 * destination state of t is final.  
	 */
	public boolean transitionAndIfFinal(
			Transition t, List<? extends CommonObj> params) {
		switch (t.name) {
			default:
				return false;
		}
	}
}
