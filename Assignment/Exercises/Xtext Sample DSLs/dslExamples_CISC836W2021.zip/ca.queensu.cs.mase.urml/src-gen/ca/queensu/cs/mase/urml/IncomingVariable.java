/**
 */
package ca.queensu.cs.mase.urml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Incoming Variable</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ca.queensu.cs.mase.urml.UrmlPackage#getIncomingVariable()
 * @model
 * @generated
 */
public interface IncomingVariable extends Identifiable
{
} // IncomingVariable
