/**
 */
package ca.queensu.cs.mase.urml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>No Op</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ca.queensu.cs.mase.urml.UrmlPackage#getNoOp()
 * @model
 * @generated
 */
public interface NoOp extends StatementOperation, Statement
{
} // NoOp
