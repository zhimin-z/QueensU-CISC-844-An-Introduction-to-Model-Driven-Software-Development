/**
 */
package ca.queensu.cs.mase.urml;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ca.queensu.cs.mase.urml.UrmlPackage#getExpression()
 * @model
 * @generated
 */
public interface Expression extends EObject
{
} // Expression
