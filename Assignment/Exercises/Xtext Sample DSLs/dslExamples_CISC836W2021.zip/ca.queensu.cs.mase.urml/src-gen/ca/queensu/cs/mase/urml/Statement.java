/**
 */
package ca.queensu.cs.mase.urml;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ca.queensu.cs.mase.urml.UrmlPackage#getStatement()
 * @model
 * @generated
 */
public interface Statement extends EObject
{
} // Statement
