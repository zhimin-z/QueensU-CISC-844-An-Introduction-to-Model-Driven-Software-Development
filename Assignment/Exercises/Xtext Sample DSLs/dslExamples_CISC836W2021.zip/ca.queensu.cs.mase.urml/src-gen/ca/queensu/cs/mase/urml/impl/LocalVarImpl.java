/**
 */
package ca.queensu.cs.mase.urml.impl;

import ca.queensu.cs.mase.urml.LocalVar;
import ca.queensu.cs.mase.urml.UrmlPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Local Var</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LocalVarImpl extends AssignableImpl implements LocalVar
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected LocalVarImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return UrmlPackage.Literals.LOCAL_VAR;
  }

} //LocalVarImpl
