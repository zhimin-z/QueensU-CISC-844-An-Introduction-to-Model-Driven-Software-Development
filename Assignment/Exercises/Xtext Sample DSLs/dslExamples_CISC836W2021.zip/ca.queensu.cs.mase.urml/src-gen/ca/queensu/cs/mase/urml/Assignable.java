/**
 */
package ca.queensu.cs.mase.urml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Assignable</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ca.queensu.cs.mase.urml.UrmlPackage#getAssignable()
 * @model
 * @generated
 */
public interface Assignable extends Identifiable
{
} // Assignable
