/**
 */
package ca.queensu.cs.mase.urml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Local Var</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ca.queensu.cs.mase.urml.UrmlPackage#getLocalVar()
 * @model
 * @generated
 */
public interface LocalVar extends Assignable
{
} // LocalVar
