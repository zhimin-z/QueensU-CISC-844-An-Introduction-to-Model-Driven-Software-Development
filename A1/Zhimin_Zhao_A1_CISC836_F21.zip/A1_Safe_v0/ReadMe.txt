Part 2:

- Test case for LockError -> '*1231' // not ending with '#' key
	
- Test case for UnLockError -> '*#' // not including any digit code

- Test case for LockSuccess -> '***123#' // multiple starting with '*' key

- Test case for UnlockSuccess -> '*1**123#' // starting with multiple '*' key but with correct 3-digit code

Part 3:

case1: LockError -> LockSuccess -> UnlockSuccess -> UnlockError | Works
case2: LockSuccess -> LockError -> UnlockError -> UnlockSuccess | Blocks

The root cause for the failed tests upon changing order is that only the [LockSuccess] phase sends out the Reset() signal, putting the safe to OPEN state.

If we switch the order to case 2, then after [LockSuccess] phase, the safe is in CLOSED state. We cannot check lock error if the safe is locked already.

One quick fix is to ensure a reset() signal at the beginning of all four phases. 